def scan_course(app):
  with app.app_context():
    from app.models.course import Course
    from app.models.scheduler import Scheduler
    from app.models.calendar import Calendar
    import time
    import pytz
    from app.models.base import db
    tz = pytz.timezone('Asia/Shanghai')
    dt = pytz.datetime.datetime.fromtimestamp(time.time(), tz)
    time_stamp = int(time.mktime(dt.timetuple()))
    courses = Course.query.filter(Course.app_deadline < time_stamp,Course.status==1).all()
    for course in courses:
      course.status = 2
      db.session.commit()
    


def scan_calendar(app):
  with app.app_context():
    from app.models.course import Course
    from app.models.scheduler import Scheduler
    from app.models.calendar import Calendar
    import time
    import pytz
    from app.models.base import db
    tz = pytz.timezone('Asia/Shanghai')
    dt = pytz.datetime.datetime.fromtimestamp(time.time(), tz)
    time_stamp = int(time.mktime(dt.timetuple()))
    calenders = Calendar.query.filter(Calendar.end_date < time_stamp,Calendar.status==1).all()
    for calender in calenders:
      calender.status = 2
      schedulers = Scheduler.query.filter_by(cal_id=calender.id).all()
      for scheduler in schedulers:
        scheduler.status = 2
      db.session.commit()
    calenders = Calendar.query.filter(Calendar.status==1).all()
    for calender in calenders:
      schedulers = Scheduler.query.filter(Scheduler.end_date < time_stamp,Scheduler.cal_id==calender.id).all()
      for scheduler in schedulers:
        scheduler.status = 2
      db.session.commit()

  