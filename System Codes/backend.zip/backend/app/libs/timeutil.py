import time
from datetime import timezone, timedelta
import datetime
from dateutil.relativedelta import relativedelta

def date_to_timestamp(date, format_string="%Y.%m.%d"):
    time_array = time.strptime(date, format_string)
    time_stamp = int(time.mktime(time_array))
    return time_stamp

def timestamp_to_data(timestamp,format_string="%Y.%m.%d"):
    timestruct = time.localtime(timestamp)
    return time.strftime(format_string, timestruct)

def timestamp_to_TZDATE(timestamp,format_string="%Y--%m--%d %H:%M:%S"):
    data = datetime.datetime.utcfromtimestamp(timestamp)
    utc_tz = timezone(timedelta(hours=0))
    data = data.replace(tzinfo=utc_tz)
    datas = data.astimezone(timezone(timedelta(hours=8)))   # 直接转带时区的时间
    return (datas.strftime("%Y-%m-%dT%H:%M:%S%Z")).replace('UTC','')

def getTime_countbyTimespan(timespan):
    today = datetime.date.today()
    datetime_ago = today - relativedelta(months=timespan)
    return int(time.mktime(datetime_ago.timetuple()))


def string_toDatetime(datastr, format_string="%Y.%m.%d"):
    return datetime.datetime.strptime(datastr, format_string)

def timestamp_to_weekday(timestamp,format_string="%Y.%m.%d"):
    date=timestamp_to_data(timestamp)
    weekday=datetime.datetime.strptime(date,format_string).weekday()
    return weekday

def get_duration_timestampList(beginTimestamp, endTimestamp, format_string="%Y.%m.%d"):
    timestampList = []
    beginDate=timestamp_to_data(beginTimestamp)
    endDate=timestamp_to_data(endTimestamp)
    dt = datetime.datetime.strptime(beginDate, format_string)
    date = beginDate[:]
    while date <= endDate:
        timestampList.append(date_to_timestamp(date))
        dt = dt + datetime.timedelta(1)
        date = dt.strftime(format_string)
    return timestampList
