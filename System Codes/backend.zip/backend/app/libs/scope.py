#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@File    :   scope.py
@Time    :   2019/03/12 12:25:00
@Author  :   Jiachen Xu
@Desc    :   None
'''


class Scope:
    allow_api = []
    allow_module = []
    forbidden = []
    allow_action = []
    allow_action_self = []

    def __add__(self, other):
        self.allow_api = self.allow_api + other.allow_api
        self.allow_api = list(set(self.allow_api))
        self.allow_module = self.allow_module + other.allow_module
        self.allow_module = list(set(self.allow_module))
        self.forbidden = self.forbidden + other.forbidden
        self.forbidden = list(set(self.forbidden))

        return self

# stuScope
class stuScope(Scope):
    allow_module = ['v1.user', 'v1.course', 'v1.adjustment',
                    'v1.appointment', 'v1.calendar']

# tchScope
class tchScope(Scope):
    allow_module = ['v1.user', 'v1.course',
                    'v1.adjustment', 'v1.appointment', 'v1.calendar']


def is_in_scope(scope, endpoint):
    scope = globals()[scope]()
    splits = endpoint.split('+')
    red_name = splits[0]
    if endpoint in scope.forbidden:
        return False
    if endpoint in scope.allow_api:
        return True
    if red_name in scope.allow_module:
        return True
    else:
        return False


def is_in_allow_actions(scope, action, isself=True):
    scope = globals()[scope]()
    if isself:
        if action in scope.allow_action_self:
            return True
        else:
            return False
    else:
        if action in scope.allow_action:
            return True
        else:
            return False
