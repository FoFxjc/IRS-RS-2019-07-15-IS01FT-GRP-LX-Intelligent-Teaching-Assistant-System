from enum import Enum

class ClientTypeEnum(Enum):
  USER_EMAIL = 100
  USER_MOBILE = 101

  USER_MINA = 200

  USER_WX = 2001

course_lifecycle = {
    '0' : {
          'action': 'create',
          'prestage': [],
        },
    '1' : {
          'action': 'start',
          'prestage': ['create', 'stop'],
        },
    '2' : {
          'action': 'stop',
          'prestage': ['start'],
    },
    '3' : {
          'action': 'doschedule',
          'prestage': ['stop'],
        },
    '4' :  {
          'action': 'doneschedule',
          'prestage': ['doschedule'],
        }
}

module_color = {
  '0':{
      'name': 'Listening',
      'color': '#9e5fff',
  },
  '1':{
      'name':'Reading',
      'color': '#00a9ff',
  },
  '2':{
      'name': 'Writing',
      'color': '#00DB00',
  },
  '3':{
      'name': 'Speaking',
      'color': '#FF5809'
  }
}

def get_action_id(action):
    return [k for k, v in course_lifecycle.items() if v['action'] == action][0]

def get_module_color(module):
    return [v['color'] for k, v in module_color.items() if v['name'] == module][0]