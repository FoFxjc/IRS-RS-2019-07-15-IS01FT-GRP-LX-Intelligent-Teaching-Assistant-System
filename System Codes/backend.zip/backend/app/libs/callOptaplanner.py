#!/usr/bin/python
# -*- coding: UTF-8 -*-

import threading
import time
import json
import xml.dom.minidom
from app import create_db_app
from app.models.course import Course
from app.models.base import db
from app.libs.timeutil import timestamp_to_weekday, get_duration_timestampList
from app.models.appointment import Appointment
from app.models.student import Student
from app.models.adjustment import Adjustment
from app.models.calendar import Calendar
from app.models.scheduler import Scheduler
from app.config.rules import RULE_ENGINE_URL

exitFlag = 0


class myThread(threading.Thread):
    def __init__(self, threadID, name, course_id):
        threading.Thread.__init__(self)
        self.threadID = threadID
        self.name = name
        self.course_id = course_id

    def run(self):
        print("Starting " + self.name)
        do_schedule(self.name, self.course_id)
        print("Exiting " + self.name)


def do_schedule(threadName, course_id):
    import requests
    app = create_db_app()
    with app.app_context():
        head = {"Content-Type": "text/xml; charset=UTF-8", 'Connection': 'close'}
        r = requests.post(RULE_ENGINE_URL, data=package_xml(course_id), headers=head)
        responsedata = r.text
        # with open('db/solved.json', 'w') as f:
        #     f.write(responsedata)

        # extract assignments lists from response json file
        solution_data = json.loads(responsedata)
        stu_assign_list=[]
        stu_id_asslist=[]
        studentAssignmentList = solution_data["studentAssignmentList"]
        for stu_assign in studentAssignmentList:
            stu_schedule = []
            stu_schedule.append(stu_assign["student"]["id"])
            stu_id_asslist.append(stu_assign["student"]["id"])
            stu_schedule.append(stu_assign["day"]["dateIndex"])
            stu_schedule.append(stu_assign["indexInDay"])
            stu_assign_list.append(stu_schedule)
        # print(day_period_asslist,stu_id_asslist)

        # create calender in mysql
        total_start = Course.query.filter_by(id=course_id).first().start_date
        total_end = Course.query.filter_by(id=course_id).first().end_date
        stu_id_ded = list(set(stu_id_asslist))
        stu_id_ded.sort(key=stu_id_asslist.index)
        stu_id_count = []
        #stu_id_ded and stu_id_count are one to one
        for i in stu_id_ded:
            stu_id_count.append(stu_id_asslist.count(i))
        # the last one's index in every same stu_id,can be used to find out the day_period bigin or end
        # stu_id_index = [0 for _ in range(len(stu_id_count))]
        # for i in range(len(stu_id_count)):
        #     for j in range(i + 1):
        #         stu_id_index[i] = stu_id_index[i] + stu_id_count[j]
        #     stu_id_index[i] = stu_id_index[i] - 1
        stu_id_dateindex_min=[]
        stu_id_dateindex_min_period=[]
        stu_id_dateindex_max=[]
        stu_id_dateindex_max_period = []
        #the same student id's dateindex and period
        stu_id_dateindex=[]
        stu_id_period=[]
        for i in range(len(stu_id_ded)):
            temp1=[]
            temp2=[]
            for j in range(len(stu_assign_list)):
                if stu_assign_list[j][0]==stu_id_ded[i]:
                    temp1.append(stu_assign_list[j][1])
                    temp2.append(stu_assign_list[j][2])
            stu_id_dateindex.append(temp1)
            stu_id_period.append(temp2)
            stu_id_dateindex_min.append(min(temp1))
            stu_id_dateindex_min_period.append(temp2[temp1.index(min(temp1))])
            stu_id_dateindex_max.append(max(temp1))
            stu_id_dateindex_max_period.append(temp2[temp1.index(max(temp1))])

        cal_id = []
        ramain_dateIndex, remain_timestamp_list,remain_weekday_list = collect_daylist(course_id)
        for i in range(len(stu_id_ded)):
            with db.auto_commit():
                cal = Calendar()
                cal.stu_id = stu_id_ded[i]
                cal.course_id = course_id
                cal.start_date=remain_timestamp_list[stu_id_dateindex_min[i]]
                cal.end_date=remain_timestamp_list[stu_id_dateindex_max[i]]
                cal.type = Appointment.query.filter_by(stu_id=stu_id_ded[i]).first().type
                cal.status = 1
                db.session.add(cal)
            cal_id.append(Calendar.query.filter_by(stu_id=stu_id_ded[i]).first().id)

        # create scheduler in mysql for every student(calender)
        for i in range(len(cal_id)):
            stu_id = Calendar.query.filter_by(id=cal_id[i]).first().stu_id
            src = Appointment.query.filter_by(stu_id=stu_id).first().recommend_speaking // 2
            rrc = Appointment.query.filter_by(stu_id=stu_id).first().recommend_reading // 2
            wrc = Appointment.query.filter_by(stu_id=stu_id).first().recommend_writing // 2
            lrc = Appointment.query.filter_by(stu_id=stu_id).first().recommend_listening // 2
            sac = stu_id_count[i]  * src // (src + rrc + wrc + lrc)
            rac = stu_id_count[i] * rrc // (src + rrc + wrc + lrc)
            wac = stu_id_count[i] * wrc // (src + rrc + wrc + lrc)
            lac = stu_id_count[i] - sac - rac - wac
            for j in range(sac):
                course_begin, course_end = dayperiod_to_timestamp(remain_timestamp_list,stu_id_dateindex[i][j],stu_id_period[i][j])
                with db.auto_commit():
                    sch = Scheduler()
                    sch.cal_id = cal_id[i]
                    sch.category = "Speaking"
                    sch.start_date = course_begin
                    sch.end_date = course_end
                    sch.detail = "Speaking"
                    sch.status = 1
                    db.session.add(sch)
            for j in range(rac):
                course_begin, course_end = dayperiod_to_timestamp(remain_timestamp_list, stu_id_dateindex[i][j+sac],stu_id_period[i][j+sac])
                with db.auto_commit():
                    sch = Scheduler()
                    sch.cal_id = cal_id[i]
                    sch.category = "Reading"
                    sch.start_date = course_begin
                    sch.end_date = course_end
                    sch.detail = "Reading"
                    sch.status = 1
                    db.session.add(sch)
            for j in range(wac):
                course_begin, course_end = dayperiod_to_timestamp(remain_timestamp_list, stu_id_dateindex[i][j+sac+rac],stu_id_period[i][j+sac+rac])
                with db.auto_commit():
                    sch = Scheduler()
                    sch.cal_id = cal_id[i]
                    sch.category = "Writing"
                    sch.start_date = course_begin
                    sch.end_date = course_end
                    sch.detail = "Writing"
                    sch.status = 1
                    db.session.add(sch)
            for j in range(lac):
                course_begin, course_end = dayperiod_to_timestamp(remain_timestamp_list, stu_id_dateindex[i][j+sac+rac+wac],stu_id_period[i][j+sac+rac+wac])
                with db.auto_commit():
                    sch = Scheduler()
                    sch.cal_id = cal_id[i]
                    sch.category = "Listening"
                    sch.start_date = course_begin
                    sch.end_date = course_end
                    sch.detail = "Listening"
                    sch.status = 1
                    db.session.add(sch)

        course = Course.query.filter_by(id=course_id).first_or_404()
        course.status = 4
        db.session.commit()
    # fp = open('testXML.xml', 'w')
    # fp.writexml(fp, indent='\t', addindent='\t', newl='\n', encoding="utf-8")
    # print('服务端的响应报文为（客户端 <--服务端）: ',responsedata)
    # print("get the status: ",r.status_code)

    # with app.app_context():

    del app


def dayperiod_to_timestamp(remain_timestamp_list, day_index, period_index):
    # 8:00-10:00 10:30-12:30 13:30-15:30 16:00-18:00
    if period_index == 0:
        course_begin = remain_timestamp_list[day_index] + 60 * 60 * 8
    elif period_index == 1:
        course_begin = remain_timestamp_list[day_index] + 60 * 60 * 10 + 60 * 30
    elif period_index == 2:
        course_begin = remain_timestamp_list[day_index] + 60 * 60 * 13 + 60 * 30
    elif period_index == 3:
        course_begin = remain_timestamp_list[day_index] + 60 * 60 * 16

    course_end = course_begin + 60 * 60 * 2

    return course_begin, course_end



#package the xml which will be sent to the Optaplanner
aft_tch_dateindex=[]
aft_tch_timestamp=[]
aft_tch_weekday=[]

def package_xml(course_id):
    # create an empty document
    doc = xml.dom.minidom.Document()

    # create root element
    root = doc.createElement("TeachingSolution")
    root.setAttribute('id', '1')

    doc.appendChild(root)

    nodeid = doc.createElement("id")
    nodeid.appendChild(doc.createTextNode("0"))
    root.appendChild(nodeid)

    # create student list elements
    nodestudentList = doc.createElement("studentList")
    nodestudentList.setAttribute('id', '2')
    root.appendChild(nodestudentList)
    stu_id, name, courseSize = collect_studentlist(course_id)
    for i in range(len(name)):
        nodeTeachingStudent = doc.createElement("TeachingStudent")
        nodeTeachingStudent.setAttribute('id', str(i + 3))

        nodeid = doc.createElement("id")
        nodeid.appendChild(doc.createTextNode(str(stu_id[i])))

        nodename = doc.createElement("name")
        nodename.appendChild(doc.createTextNode(str(name[i])))

        nodecourseSize = doc.createElement("courseSize")
        nodecourseSize.appendChild(doc.createTextNode(str(courseSize[i])))

        nodeTeachingStudent.appendChild(nodeid)
        nodeTeachingStudent.appendChild(nodename)
        nodeTeachingStudent.appendChild(nodecourseSize)
        nodestudentList.appendChild(nodeTeachingStudent)

    # create day list elements
    nodedayList = doc.createElement("dayList")
    nodedayList.setAttribute('id', '501')
    root.appendChild(nodedayList)

    ramain_dateIndex, remain_timestamp_list,remain_weekday_list = collect_daylist(course_id)

    for i in range(len(ramain_dateIndex)):
        nodeTeachingDay = doc.createElement("TeachingDay")
        nodeTeachingDay.setAttribute("id", str(i + 502))

        nodeid = doc.createElement("id")
        nodeid.appendChild(doc.createTextNode(str(i)))

        nodedateIndex = doc.createElement("dateIndex")
        nodedateIndex.appendChild(doc.createTextNode(str(ramain_dateIndex[i])))

        nodeTeachingDay.appendChild(nodeid)
        nodeTeachingDay.appendChild(nodedateIndex)
        nodedayList.appendChild(nodeTeachingDay)

    # create unavailability penalty list
    nodeunavailabilityPenaltyList = doc.createElement("unavailabilityPenaltyList")
    nodeunavailabilityPenaltyList.setAttribute('id', '2001')
    root.appendChild(nodeunavailabilityPenaltyList)

    UPlist = collect_UPlist(course_id)
    # print(UPlist)

    for i in range(len(UPlist)):
        nodeTeachingUnavailabilityPenalty = doc.createElement("TeachingUnavailabilityPenalty")
        nodeTeachingUnavailabilityPenalty.setAttribute("id", str(i + 2002))

        nodeid = doc.createElement("id")
        nodeid.appendChild(doc.createTextNode(str(i)))

        nodestudent = doc.createElement("student")
        nodestudent.setAttribute("reference", str(UPlist[i][0]))

        nodeperiod = doc.createElement("day")
        nodeperiod.setAttribute("reference", str(UPlist[i][1]))

        nodeTeachingUnavailabilityPenalty.appendChild(nodeid)
        nodeTeachingUnavailabilityPenalty.appendChild(nodestudent)
        nodeTeachingUnavailabilityPenalty.appendChild(nodeperiod)
        nodeunavailabilityPenaltyList.appendChild(nodeTeachingUnavailabilityPenalty)

    # create student assignment list
    nodestudentAssignmentList = doc.createElement("studentAssignmentList")
    nodestudentAssignmentList.setAttribute('id', '4001')
    root.appendChild(nodestudentAssignmentList)
    for i in range(len(ramain_dateIndex)):
        for j in range(0, 4):
            nodeTeachingStudentAssignment = doc.createElement("TeachingStudentAssignment")
            nodeTeachingStudentAssignment.setAttribute("id", str(i + j + 4002))

            nodeid = doc.createElement("id")
            nodeid.appendChild(doc.createTextNode(str(i * 4 + j)))

            nodeperiod = doc.createElement("day")
            nodeperiod.setAttribute("reference", str(ramain_dateIndex[i] + 502))

            nodeindexInPeriod = doc.createElement("indexInDay")
            nodeindexInPeriod.appendChild(doc.createTextNode(str(j % 4)))

            nodepinned = doc.createElement("pinned")
            nodepinned.appendChild(doc.createTextNode("false"))

            nodeTeachingStudentAssignment.appendChild(nodeid)
            nodeTeachingStudentAssignment.appendChild(nodeperiod)
            nodeTeachingStudentAssignment.appendChild(nodeindexInPeriod)
            nodeTeachingStudentAssignment.appendChild(nodepinned)
            nodestudentAssignmentList.appendChild(nodeTeachingStudentAssignment)

    # create and write XML file
    fp = open('db/testXML.xml', 'w')
    doc.writexml(fp, indent='\t', addindent='\t', newl='\n')

    return doc.toxml()


def collect_studentlist(course_id):
    appointment = Appointment.query.filter_by(course_id=course_id).all()
    appointment_valid = []
    for i in range(len(appointment)):
        if appointment[i].status == 2:
            appointment_valid.append(appointment[i])

    stu_id = []
    name = []
    courseSize = []
    for i in range(len(appointment_valid)):
        stu_id.append(appointment_valid[i].stu_id)
        name.append(Student.query.filter_by(id=stu_id[i]).first().name)
        courseSize.append((appointment_valid[i].recommend_speaking
                           + appointment_valid[i].recommend_reading
                           + appointment_valid[i].recommend_writing
                           + appointment_valid[i].recommend_listening) // 2)
    return stu_id, name, courseSize


def collect_daylist(course_id):
    course = Course.query.filter_by(id=course_id).first()
    start_timestamp = course.start_date
    end_timestamp = course.end_date

    # course day list save as timestamp and weekday seperately
    timestamp_list = get_duration_timestampList(start_timestamp, end_timestamp)
    count_byday = len(timestamp_list)
    weekday_list = []
    for i in range(count_byday):
        weekday_list.append(timestamp_to_weekday(timestamp_list[i]))

    # delete(set value to 0) some days in course day list according to the teacher's adjustments
    tch_adj_list = course.tch_adjustments
    tch_adj_list = adj_str2list(tch_adj_list)
    tch_adjustments = []
    for i in range(0, len(tch_adj_list)):
        tch_adjustments.append(Adjustment.query.filter_by(id=tch_adj_list[i]).first().key)
    tch_del_index = []
    remain_timestamp_list = []
    remain_weekday_list=[]
    for i in range(len(tch_adjustments)):
        for j in range(len(weekday_list)):
            if weekday_list[j] == tch_adjustments[i]:
                tch_del_index.append(j)
                # timestamp_list[j]=0
                count_byday = count_byday - 1
            else:
                remain_timestamp_list.append(timestamp_list[j])
                remain_weekday_list.append(weekday_list[j])

    ramain_dateIndex = []
    for i in range(count_byday):
        ramain_dateIndex.append(i)

    return ramain_dateIndex, remain_timestamp_list,remain_weekday_list


def collect_UPlist(course_id):
    appointment = Appointment.query.filter_by(course_id=course_id).all()
    appointment_valid = []
    appointment_valid_stu_id=[]
    for i in range(len(appointment)):
        if appointment[i].status == 2:
            appointment_valid.append(appointment[i])
            appointment_valid_stu_id.append(appointment[i].stu_id)

    course = Course.query.filter_by(id=course_id).first()
    # tch_adjustments = course.tch_adjustments
    # tch_adjustments = adj_str2list(tch_adjustments)
    tch_adj_id = course.tch_adjustments
    tch_adj_id = adj_str2list(tch_adj_id)
    tch_adjustments = []
    for i in range(0, len(tch_adj_id)):
        tch_adjustments.append(Adjustment.query.filter_by(id=tch_adj_id[i]).first().key)

    stu_adj_id = []
    stu_adjustments = []
    for i in range(len(appointment_valid)):
        stu_adj_id.append(adj_str2list(appointment_valid[i].stu_adjustments))
    for i in range(len(stu_adj_id)):
        a = []
        for j in range(len(stu_adj_id[i])):
            a.append(Adjustment.query.filter_by(id=stu_adj_id[i][j]).first().key)
        stu_adjustments.append(a)

    # delete the same adjustment between teacher's  and students' in stu_dajustments
    for i in range(len(stu_adjustments)):
        for j in range(len(tch_adjustments)):
            for k in stu_adjustments[i]:
                if k in tch_adjustments:
                    stu_adjustments[i].remove(k)

    ramain_dateIndex, remain_timestamp_list, remain_weekday_list=collect_daylist(course_id)

    # #count the number of unavailabilityPenalty
    # count=0
    # for i in range(len(stu_adjustments)):
    #     count=count+len(stu_adjustments[i])

    UPlist = []
    mon_index, tues_index, wed_index, thur_index, fri_index, sat_index, sun_index = weekday_index(remain_weekday_list)
    for i in range(len(stu_adjustments)):
        for j in range(len(stu_adjustments[i])):
            if stu_adjustments[i][j] == 0:
                for k in range(len(mon_index)):
                    UPlist.append([i+3, mon_index[k] + 502])
            elif stu_adjustments[i][j] == 1:
                for k in range(len(tues_index)):
                    UPlist.append([i+3, tues_index[k] + 502])
            elif stu_adjustments[i][j] == 2:
                for k in range(len(wed_index)):
                    UPlist.append([i+3, wed_index[k] + 502])
            elif stu_adjustments[i][j] == 3:
                for k in range(len(thur_index)):
                    UPlist.append([i+3, thur_index[k] + 502])
            elif stu_adjustments[i][j] == 4:
                for k in range(len(fri_index)):
                    UPlist.append([i+3, fri_index[k] + 502])
            elif stu_adjustments[i][j] == 5:
                for k in range(len(sat_index)):
                    UPlist.append([i+3, sat_index[k] + 502])
            elif stu_adjustments[i][j] == 6:
                for k in range(len(sun_index)):
                    UPlist.append([i+3, sun_index[k] + 502])

    return UPlist


def adj_str2list(adj_str):
    if adj_str and adj_str != "[]":
        adj_str = adj_str[1:-1]
        adj_list = adj_str.split(',')
        return adj_list
    else:
        return []


def weekday_index(remain_weekday_list):
    # course = Course.query.filter_by(id=course_id).first()
    # start_timestamp = course.start_date
    # end_timestamp = course.end_date
    #
    # # course day list save as timestamp and weekday seperately
    # # timestamp_list = get_duration_timestampList(start_timestamp, end_timestamp)
    # # count_byday = len(timestamp_list)
    # # weekday_list = []
    # # for i in range(0, count_byday):
    # #     weekday_list.append(timestamp_to_weekday(timestamp_list[i]))
    #
    # # tch_adjustments = course.tch_adjustments
    # # tch_del_index = []
    # # for i in range(len(tch_adjustments)):
    # #     for j in range(len(weekday_list)):
    # #         if weekday_list[j] == tch_adjustments[i]:
    # #             tch_del_index.append(j)
    # #             timestamp_list[j] = 0
    # #             weekday_list.pop(j)
    # #             count_byday = count_byday - 1
    #
    # timestamp_list = get_duration_timestampList(start_timestamp, end_timestamp)
    # count_byday = len(timestamp_list)
    # weekday_list = []
    # for i in range(count_byday):
    #     weekday_list.append(timestamp_to_weekday(timestamp_list[i]))
    # tch_adj_id = course.tch_adjustments
    # tch_adj_id = adj_str2list(tch_adj_id)
    # tch_adjustments = []
    # for i in range(0, len(tch_adj_id)):
    #     tch_adjustments.append(Adjustment.query.filter_by(id=tch_adj_id[i]).first().key)
    # remain_timestamp_list = []
    # remain_weekday_list = []
    # tch_del_index = []
    # for i in range(len(tch_adjustments)):
    #     for j in range(len(weekday_list)):
    #         if weekday_list[j] == tch_adjustments[i]:
    #             tch_del_index.append(j)
    #             count_byday = count_byday - 1
    #         else:
    #             remain_timestamp_list.append(timestamp_list[j])
    #             remain_weekday_list.append(weekday_list[j])

    mon_index = []
    tues_index = []
    wed_index = []
    thur_index = []
    fri_index = []
    sat_index = []
    sun_index = []
    for i in range(len(remain_weekday_list)):
        if remain_weekday_list[i] == 0:
            mon_index.append(i)
        elif remain_weekday_list[i] == 1:
            tues_index.append(i)
        elif remain_weekday_list[i] == 2:
            wed_index.append(i)
        elif remain_weekday_list[i] == 3:
            thur_index.append(i)
        elif remain_weekday_list[i] == 4:
            fri_index.append(i)
        elif remain_weekday_list[i] == 5:
            sat_index.append(i)
        elif remain_weekday_list[i] == 6:
            sun_index.append(i)
    return mon_index, tues_index, wed_index, thur_index, fri_index, sat_index, sun_index


def callOptaplanner(course_id):
    print(course_id)
    thread1 = myThread(1, "Scheduler-" + str(course_id), course_id)
    thread1.start()