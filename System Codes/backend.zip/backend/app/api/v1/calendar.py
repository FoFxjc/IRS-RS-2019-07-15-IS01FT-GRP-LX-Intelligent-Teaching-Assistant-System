"""
 Created by jiachenx on 2018/5/28.
"""
import time
import copy
import re
from flask import g, jsonify

from app.libs.enums import get_action_id
from app.libs.error_code import AuthFailed, DuplicateGift, Success
from app.libs.redprint import Redprint
from app.libs.scope import is_in_allow_actions
from app.libs.timeutil import date_to_timestamp, getTime_countbyTimespan
from app.libs.token_auth import auth
from app.models.base import db
from app.models.course import Course
from app.models.calendar import Calendar
from app.models.student import Student
from app.models.teacher import Teacher
from app.models.scheduler import Scheduler
from app.libs.utils import generate_detail
from app.viewmodels.calendar import CalendarViewModel_stu,CalendarViewModel_tch
from app.validators.forms import GetCalendarByCidForm

__author__ = 'jiachenx'

api = Redprint('calendar')


@api.route('/list', methods=['POST'])
@auth.login_required
def list():
    uid = g.user.uid
    scope = g.user.scope
    if 'stu' in scope:
        stu = Student.query.filter_by(id=uid).first_or_404()
        stu_calendar = Calendar.query.filter_by(stu_id=stu.id,status=1).all()
        if stu_calendar:
            calendarCollection = CalendarViewModel_stu(stu_calendar[0])
            return jsonify(calendarCollection.data)
        else:
            return jsonify({})
    elif 'tch' in scope:
        tch = Teacher.query.filter_by(id=uid).first_or_404()
        tch_course = Course.query.filter_by(tch_id=tch.id,status=4).first()
        if tch_course:
            tch_calendar = Calendar.query.filter_by(course_id=tch_course.id,status=1).all()
            calendarCollection = CalendarViewModel_tch(tch_calendar)
            return jsonify(calendarCollection.data)
        else:
            return jsonify({})


@api.route('/getCalendarByCid', methods=['POST'])
@auth.login_required
def getCalendarByCid():
    uid = g.user.uid
    scope = g.user.scope
    form  = GetCalendarByCidForm().validate_for_api()
    if 'stu' in scope:
        stu = Student.query.filter_by(id=uid).first_or_404()
        stu_calendar = Calendar.query.filter_by(stu_id=stu.id,course_id=form.course_id.data).all()
        if stu_calendar:
            calendarCollection = CalendarViewModel_stu(stu_calendar[0])
            return jsonify(calendarCollection.data)
        else:
            return jsonify({})
    elif 'tch' in scope:
        tch = Teacher.query.filter_by(id=uid).first_or_404()
        tch_calendar = Calendar.query.filter_by(course_id=form.course_id.data).all()
        if tch_calendar:
            calendarCollection = CalendarViewModel_tch(tch_calendar)
            return jsonify(calendarCollection.data)
        else:
            return jsonify({})

 