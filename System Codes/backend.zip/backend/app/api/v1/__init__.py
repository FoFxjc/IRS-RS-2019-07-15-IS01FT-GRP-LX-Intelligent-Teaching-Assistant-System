from flask import Blueprint
from app.api.v1 import (token,user,adjustment,course,appointment,calendar)

def create_blueprint_v1():
  bp_v1 = Blueprint('v1',__name__)
  user.api.register(bp_v1)
  token.api.register(bp_v1)
  adjustment.api.register(bp_v1)
  course.api.register(bp_v1)
  appointment.api.register(bp_v1)
  calendar.api.register(bp_v1)
  return bp_v1
