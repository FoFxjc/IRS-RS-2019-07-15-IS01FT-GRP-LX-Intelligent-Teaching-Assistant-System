"""
 Create by jiachenx on 2019/3/11
"""
import copy

from flask import g, jsonify
from sqlalchemy import or_

from app.libs.enums import roles
from app.libs.error_code import (AuthFailed, DeleteSuccess,
                                 ParameterExceptionWarning, Success)
from app.libs.redprint import Redprint
from app.libs.token_auth import auth
from app.libs.utils import generate_detail
from app.models.base import db
from app.models.student import Student
from app.models.teacher import Teacher
from app.validators.forms import (AddUserForm, RegisterForm,
                                  UpdatePasswordForm, UpdateUserForm,
                                  UserInfoSearchForm)
from app.viewmodels.user import StudentViewModel, TeacherViewModel

__author__ = 'jiachenx'

api = Redprint('user')


@api.route('/update', methods=['POST'])
@auth.login_required
def update_user():
  form = UpdateUserForm().validate_for_api()
  print(form)
  if form.domain.data == "stu":
    user = Student.query.filter_by(id=form.id.data).first_or_404()
  if form.domain.data == "tch":
    tch = Teacher.query.filter_by(id=form.id.data).first_or_404()
  compare_temp_data = copy.copy(user)
  user.name = form.name.data
  user.email = form.email.data
  user.age = form.age.data
  user.color = form.color.data
  user.gender = form.gender.data
  compare_result = generate_detail(user, compare_temp_data)
  if any(compare_result):
    db.session.commit()
    del compare_result
    del compare_temp_data
  else:
    del compare_result
    del compare_temp_data
    return Success(msg="The update data is the same as the original one, Save Nothing")
  return Success(msg="Save Successfully")


@api.route('/info', methods=['GET'])
@auth.login_required
def get_user():
  # g 变量线程隔离
  uid = g.user.uid
  scope = g.user.scope
  if 'stu' in scope:
    user = Student.query.filter_by(id=uid).first_or_404()
    uservm = StudentViewModel(user)
  elif 'tch' in scope:
    user = Teacher.query.filter_by(id=uid).first_or_404()
    uservm = TeacherViewModel(user)
  return jsonify(uservm)


@api.route('/updatepassword', methods=['POST'])
@auth.login_required
def update_password():
  # g 变量线程隔离
  uid = g.user.uid
  scope = g.user.scope
  form = UpdatePasswordForm().validate_for_api()
  if 'stu' in scope:
    user = Student.query.filter_by(id=uid).first_or_404()
  elif 'tch' in scope:
    user = Teacher.query.filter_by(id=uid).first_or_404()
  if(user.check_password(form.oldpwd.data)):
    compare_temp_data = copy.copy(user)
    user.password = form.newpwd.data
    db.session.commit()
    return Success(msg="Change Password Successfully")
  else:
    return ParameterExceptionWarning(msg="Wrong Old Password")


@api.route('/register', methods=['POST'])
def stu_register():
  form = RegisterForm().validate_for_api()
  if(Student.isDuplicatedName(form.name.data)):
    return ParameterExceptionWarning(msg="Duplicated Name, Please try another name")
  with db.auto_commit():
    stu = Student()
    stu.name = form.name.data
    stu.password = form.password.data
    stu.gender = form.gender.data
    stu.age = form.age.data
    stu.color = form.color.data
    stu.email = form.email.data
    db.session.add(stu)
  return Success(msg="Register Successfully")
