import copy
import time

from flask import g, jsonify

from app.libs.enums import get_action_id, course_lifecycle
from app.libs.error_code import AuthFailed, DuplicateGift, Success, ParameterExceptionWarning
from app.libs.redprint import Redprint
from app.libs.scope import is_in_allow_actions
from app.libs.timeutil import (date_to_timestamp, getTime_countbyTimespan,
                               string_toDatetime,get_duration_timestampList,timestamp_to_weekday)
from app.libs.token_auth import auth
from app.libs.utils import generate_detail
from app.models.base import db
from app.models.course import Course
from app.models.student import Student
from app.models.teacher import Teacher
from app.models.adjustment import Adjustment

from app.validators.forms import CourseAddForm,CourseSearchForm,AskForSchedulerResultForm,LiftCycleForm,GetTotalClassNum
from app.viewmodels.course import CourseCollection, CourseViewModel

from app.libs.callOptaplanner import callOptaplanner

import requests
import threading


api = Redprint('course')

@api.route('/list', methods=['POST'])
@auth.login_required
def list():
    form = CourseSearchForm().validate_for_api()
    uid = g.user.uid
    queryfilter = []
    if form.id.data and form.id.data != 0:
        queryfilter.append(Course.id == form.id.data)
    courses = Course.query.filter(*queryfilter).all()
    courseCollection = CourseCollection()
    courseCollection.fill(courses)
    return jsonify(courseCollection.data)

@api.route('/askforsch', methods=['GET'])
@auth.login_required
def askForSchedulerResult():
    form = AskForSchedulerResultForm().validate_for_api()
    course = Course.query.filter_by(id=form.id.data).first_or_404()
    if course.status == 4:
        return Success()
    else:
        return ParameterExceptionWarning()



@api.route('/getTotalClassNum',methods=['POST'])
def getTotalClassNum():
    form = GetTotalClassNum().validate_for_api()
    start_timestamp=date_to_timestamp(form.start_date.data)
    end_timestamp=date_to_timestamp(form.end_date.data)
    adjustments = form.adjustments.data

    #course day list save as timestamp and weekday seperately
    timestamp_list = get_duration_timestampList(start_timestamp, end_timestamp)
    count_byday = len(timestamp_list)
    weekday_list = []
    for i in range(count_byday):
        weekday_list.append(timestamp_to_weekday(timestamp_list[i]))
    tch_adjustments = []
    # delete(set value to 0) some days in course day list according to the teacher's adjustments
    for i in range(0, len(adjustments)):
        tch_adjustments.append(Adjustment.query.filter_by(id=adjustments[i]).first().key)
    tch_del_index = []
    remain_timestamp_list = []
    remain_weekday_list=[]
    for i in range(len(tch_adjustments)):
        for j in range(len(weekday_list)):
            if weekday_list[j] == tch_adjustments[i]:
                tch_del_index.append(j)
                # timestamp_list[j]=0
                count_byday = count_byday - 1
            else:
                remain_timestamp_list.append(timestamp_list[j])
                remain_weekday_list.append(weekday_list[j])

    totalClassNum = len(remain_timestamp_list)*4
    return jsonify({"totalClassNum":totalClassNum})


@api.route('/update', methods=['POST'])
@auth.login_required
def create():
    form = CourseAddForm().validate_for_api()
    uid = g.user.uid
    # Create
    if not form.id.data:
        course = Course()
        # Create data
        with db.auto_commit():
            course.name = form.name.data
            course.types = str(form.types.data)
            course.start_date = date_to_timestamp(form.start_date.data)
            course.end_date = date_to_timestamp(form.end_date.data)
            course.tch_id = uid
            course.tch_adjustments = str(form.personal_adjustments.data)
            course.detail = form.detail.data
            course.app_deadline = date_to_timestamp(form.app_deadline.data)
            course.classes_num_limited = form.classes_num_limited.data
            course.status = 1
            db.session.add(course)
    else:
        course = Course.query.filter_by(id=form.id.data).first_or_404()
        # 临时对象 用于比较差异
        compare_temp_data = copy.copy(course)

        course.name = form.name.data
        course.types = str(form.types.data)
        course.start_date = date_to_timestamp(form.start_date.data)
        course.end_date = date_to_timestamp(form.end_date.data)
        course.tch_id = uid
        course.tch_adjustments = str(form.personal_adjustments.data)
        course.detail = form.detail.data
        course.app_deadline = date_to_timestamp(form.app_deadline.data)
        course.classes_num_limited = form.classes_num_limited.data
        
        compare_result = generate_detail(course, compare_temp_data)

        if any(compare_result):
            db.session.commit()
        else:
            return Success(msg="The update data is the same as the original one, Save Nothing")

        del compare_result
        del compare_temp_data

    return Success(msg="Save Successfully")



@api.route('/updatelifecycle', methods=['POST'])
@auth.login_required
def updatelifecycle():
    form = LiftCycleForm().validate_for_api()
    uid = g.user.uid
    scope = g.user.scope
    course = Course.query.filter_by(id=form.id.data).first_or_404()
    isself = False
    if course.tch_id == uid:
        isself = True
    if not isself:
        return AuthFailed()
    else:
        current_status = {
            'code': int(course.status),
            'value': course_lifecycle[str(course.status)]
        }
        action_status = {
            'code': int(get_action_id(form.action.data)),
            'value': course_lifecycle[get_action_id(form.action.data)]
        }
        if current_status['code'] <= action_status['code'] or current_status['value']['action'] in action_status['value']['prestage']:
            print(get_action_id(form.action.data))
            if get_action_id(form.action.data) == '3':
                callOptaplanner(form.id.data)
                course.status = get_action_id(form.action.data)
                db.session.commit()
                return Success("Course "+str(form.id.data)+"Scheduling")
            course.status = get_action_id(form.action.data)
            db.session.commit()

        ## if status is resolved， will generate a row data in the project_info table

        return Success()