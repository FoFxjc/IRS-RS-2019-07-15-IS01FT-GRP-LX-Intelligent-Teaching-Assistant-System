"""
 Create by jiachenx on 2019/3/11
"""
from flask import jsonify
from sqlalchemy import or_
import copy
from app.libs.error_code import Success
from app.libs.redprint import Redprint
from app.libs.token_auth import auth
from app.models.base import db
from app.models.adjustment import Adjustment
from app.viewmodels.adjustment import AdjustmentCollection

__author__ = 'jiachenx'

api = Redprint('adjustment')


@api.route('/list', methods=['GET'])
def list():
    adjustment = Adjustment.query.all()
    adjustmentcollection = AdjustmentCollection()
    adjustmentcollection.fill(adjustment)
    return jsonify(adjustmentcollection.data)

