import copy
import time

from flask import g, jsonify
from sqlalchemy import and_

from app.libs.enums import get_action_id
from app.libs.error_code import AuthFailed, DuplicateGift, Success
from app.libs.redprint import Redprint
from app.libs.scope import is_in_allow_actions
from app.libs.timeutil import (date_to_timestamp, getTime_countbyTimespan,
                               string_toDatetime)
from app.libs.token_auth import auth
from app.libs.utils import generate_detail
from app.models.appointment import Appointment
from app.models.base import db
from app.models.course import Course
from app.models.student import Student
from app.models.teacher import Teacher
from app.validators.forms import (
    AppointmentAddForm, AppointmentCalculateForm, AppointmentSearchByCourseid,
    AppointmentSearchByStuidandCourseid, AppointmentSearchForm,
    updateAppoinmentStatusForm)
from app.viewmodels.appointment import (AppointmentCollection,
                                        AppointmentViewModel)
from app.viewmodels.course import CourseCollection, CourseViewModel

api = Redprint('appointment')

@api.route('/list', methods=['POST'])
@auth.login_required
def list():
    form = AppointmentSearchForm().validate_for_api()
    uid = g.user.uid
    queryfilter = []
    if form.course_id.data and form.course_id.data != 0:
        queryfilter.append(Appointment.course_id == form.course_id.data)
    if form.type.data and form.type.data != 0:
        queryfilter.append(Appointment.type == form.type.data)
    if form.stu_name.data and form.stu_name.data !="":
        students = Student.query.filter(
            Student.name.like("%" + form.stu_name.data + "%")).all()
        if len(students) > 0 :
            stu_ids = [student.id for student in students]
            queryfilter.append(Appointment.stu_id.in_(stu_ids))
    if form.status.data:
        queryfilter.append(Appointment.status == form.status.data)
    appointments = Appointment.query.filter(and_(*queryfilter)).all()
    appointCollection = AppointmentCollection()
    appointCollection.fill(appointments)
    results = Course.query.with_entities(
            Course.id).distinct().all()
    list_data = {}
    if form.course_id.data and form.course_id.data != 0:
        target_course = Course.query.filter_by(id=form.course_id.data).first_or_404()
        list_data['target_course'] = CourseViewModel(target_course)
    list_data['course_ids'] = [result.id for result in results]
    list_data['appointments'] = appointCollection.data
    return jsonify(list_data)



@api.route('/calculate', methods=['POST'])
@auth.login_required
def module_calculate():
    form = AppointmentCalculateForm().validate_for_api()
    recommend_data = {}
    uid = g.user.uid
    stu = Student.query.filter_by(id=uid).first_or_404()
    recommend_data['listening'] = Appointment.calculate_recommendation_point(form.point_listening.data,form.target_listening.data,stu,'listening',form.type.data)
    recommend_data['reading'] = Appointment.calculate_recommendation_point(form.point_reading.data,form.target_reading.data,stu,'reading',form.type.data)
    recommend_data['writing'] = Appointment.calculate_recommendation_point(form.point_writing.data,form.target_writing.data,stu,'writing',form.type.data)
    recommend_data['speaking'] = Appointment.calculate_recommendation_point(form.point_speaking.data,form.target_speaking.data,stu,'speaking',form.type.data)
    return jsonify(recommend_data)


@api.route('/searchbysidcid', methods=['POST'])
@auth.login_required
def detailByStuidandCourseid():
    form = AppointmentSearchByStuidandCourseid().validate_for_api()
    appointment_sql = Appointment.query.filter_by(stu_id=form.stu_id.data,course_id=form.course_id.data).first()
    if appointment_sql:
        appointment = AppointmentViewModel(appointment_sql)
        return jsonify(appointment)
    else:
        return jsonify({})

@api.route('/searchbycid', methods=['POST'])
@auth.login_required
def detailByCourseid():
    form = AppointmentSearchByCourseid().validate_for_api()
    appointments_sql = Appointment.query.filter_by(course_id=form.course_id.data).all()
    if appointments_sql:
        appointments = AppointmentCollection()
        appointments.fill(appointments_sql)
        return jsonify(appointments.data)
    else:
        return jsonify([])

@api.route('/updatestatus',methods=['POST'])
def updateAppoinmentstatus():
    form = updateAppoinmentStatusForm().validate_for_api()
    appointment = Appointment.query.filter_by(id=form.app_id.data).first_or_404()
    appointment.status = int(form.status.data)
    db.session.commit()
    return Success()

@api.route('/update', methods=['POST'])
@auth.login_required
def create():
    form = AppointmentAddForm().validate_for_api()
    uid = g.user.uid
    # Create
    if form.id.data is None:
        appointment = Appointment()
        # Create data
        with db.auto_commit():
            appointment.course_id = form.course_id.data
            appointment.type = form.course_type.data
            appointment.point_speaking = form.point_speaking.data
            appointment.point_reading = form.point_reading.data
            appointment.point_writing = form.point_writing.data
            appointment.point_listening = form.point_listening.data
            appointment.point_total = form.point_total.data
            appointment.target_speaking = form.target_speaking.data
            appointment.target_reading = form.target_reading.data
            appointment.target_writing = form.target_writing.data
            appointment.target_listening = form.target_listening.data
            appointment.target_total = form.target_total.data
            appointment.recommend_speaking = form.recommend_speaking.data
            appointment.recommend_reading = form.recommend_reading.data
            appointment.recommend_writing = form.recommend_writing.data
            appointment.recommend_listening = form.recommend_listening.data
            appointment.stu_adjustments = str(form.stu_adjustments.data)
            appointment.stu_id = uid
            appointment.status = 1
            db.session.add(appointment)
    else:
        appointment = Appointment.query.filter_by(id=form.id.data).first_or_404()
        # 临时对象 用于比较差异
        compare_temp_data = copy.copy(appointment)

        appointment.course_id = form.course_id.data
        appointment.course_type = form.course_type.data
        appointment.point_speaking = form.point_speaking.data
        appointment.point_reading = form.point_reading.data
        appointment.point_writing = form.point_writing.data
        appointment.point_listening = form.point_listening.data
        appointment.point_total = form.point_total.data
        appointment.target_speaking = form.target_speaking.data
        appointment.target_reading = form.target_reading.data
        appointment.target_writing = form.target_writing.data
        appointment.target_listening = form.target_listening.data
        appointment.target_total = form.target_total.data
        appointment.recommend_speaking = form.recommend_speaking.data
        appointment.recommend_reading = form.recommend_reading.data
        appointment.recommend_writing = form.recommend_writing.data
        appointment.recommend_listening = form.recommend_listening.data
        appointment.stu_adjustments = str(form.stu_adjustments.data)
        appointment.stu_id = uid

        compare_result = generate_detail(appointment, compare_temp_data)

        if any(compare_result):
            db.session.commit()
        else:
            return Success(msg="The update data is the same as the original one, Save Nothing")

        del compare_result
        del compare_temp_data

    return Success(msg="Save Successfully")


@api.route('/<int:pid>', methods=['GET'])
@auth.login_required
def detail(pid):
    uid = g.user.uid
    appointment_sql = Appointment.query.filter_by(id=pid).first_or_404()
    appointment = AppointmentViewModel(appointment_sql)
    return jsonify(appointment)


@api.route('/foredit/<int:pid>', methods=['GET'])
@auth.login_required
def detail_foredit(pid):
    uid = g.user.uid
    project_sql = Project.query.filter_by(id=pid).first_or_404()
    project = ProjectViewModel(project_sql, uid, foredit=True, fordetail=True)
    return jsonify(project)


@api.route('/updatelifecycle', methods=['POST'])
@auth.login_required
def updatelifecycle():
    form = LiftCycleForm().validate_for_api()
    uid = g.user.uid
    scope = g.user.scope
    project = Project.query.filter_by(id=form.app_id.data).first_or_404()
    isself = False
    if project.creator_id == uid:
        isself = True
    if not is_in_allow_actions(scope, form.action.data, isself):
        return AuthFailed()
    else:
        current_status = {
            'code': int(project.status),
            'value': lifecycle[str(project.status)]
        }
        action_status = {
            'code': int(get_action_id(form.action.data)),
            'value': lifecycle[get_action_id(form.action.data)]
        }
        if action_status['value']['action'] == "Assign":
            form = AssignLiftCycleForm().validate_for_api()
        if current_status['code'] <= action_status['code'] or current_status['value']['action'] in action_status['value']['prestage']:
            last_history = History.get_app_last_history("project", project.id)
            with db.auto_commit():
                history = History()
                history.app_type = "project"
                history.app_id = project.id
                history.status = get_action_id(form.action.data)
                history.pre_status_id = last_history.id
                history.operator_id = uid
                if action_status['value']['action'] == "Assign":
                    history.to_operator = form.to_operator_id.data
                history.detail = form.action.data+' : '+form.comments.data
                db.session.add(history)
            project.status = get_action_id(form.action.data)
            db.session.commit()

        ## if status is resolved， will generate a row data in the project_info table

        return Success()
