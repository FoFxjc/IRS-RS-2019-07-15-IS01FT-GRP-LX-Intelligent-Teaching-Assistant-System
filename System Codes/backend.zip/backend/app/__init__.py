#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@File    :   __init__.py
@Time    :   2019/03/12 10:52:07
@Author  :   Jiachen Xu
@Desc    :   None
'''
from .app import Flask
from flask_mail import Mail, Message
from flask_cors import CORS
from flask_apscheduler import APScheduler
from app.libs.tasks import scan_course,scan_calendar
import pytz
# here put the import lib
def register_blueprints(app):
  from app.api.v1 import create_blueprint_v1
  app.register_blueprint(create_blueprint_v1(), url_prefix='/v1')

def register_plugin(app):
  from app.models.base import db
  db.init_app(app)
  with app.app_context():
    db.create_all()

def create_app():
  app = Flask(__name__)
  cors = CORS(app, resources={r"/": {"origins": "*"}})
  app.config.from_object('app.config.setting')
  app.config.from_object('app.config.secure')
  app.config.from_object('app.config.scheduler')
  register_blueprints(app)
  register_plugin(app)
  scheduler=APScheduler()
  scheduler.init_app(app)
  scheduler.start()
  timezone = pytz.timezone('Asia/Shanghai')
  scheduler.add_job(func=scan_course, trigger='cron',args=[app],hour='1', minute='0', second='0',id='scan_course',timezone=timezone)
  scheduler.add_job(func=scan_calendar, trigger='cron',args=[app],hour='1', minute='30', second='0',id='scan_calendar',timezone=timezone)
  return app

def create_db_app():
  app = Flask(__name__)
  app.config.from_object('app.config.setting')
  app.config.from_object('app.config.secure')
  register_plugin(app)
  return app