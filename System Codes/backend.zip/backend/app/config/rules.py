# DEV
#RULE_ENGINE_URL = "http://localhost:8080/solve"

# Docker
RULE_ENGINE_URL = "http://springboot:8080/solve"