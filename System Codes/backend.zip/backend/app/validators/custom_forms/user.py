from wtforms import StringField, IntegerField, DateField, FieldList
from wtforms.validators import DataRequired, length, Email, Regexp
from wtforms import ValidationError
from app.validators.base import BaseForm
from wtforms.validators import DataRequired

class ClientForm(BaseForm):
    domain = StringField(validators=[DataRequired()])
    username = StringField(validators=[DataRequired()])
    password = StringField(validators=[DataRequired()])


class AddUserForm(BaseForm):
    name = StringField(validators=[DataRequired()])
    email = StringField(validators=[
        Email(message='invalidate email')
    ])
    auth = StringField(validators=[DataRequired()])


class UpdateUserForm(BaseForm):
    id = IntegerField(validators=[DataRequired()])
    name = StringField(validators=[DataRequired()])
    domain = StringField(validators=[DataRequired()])
    password = StringField(validators=[DataRequired()])
    age = IntegerField(validators=[DataRequired()])
    gender = StringField(validators=[DataRequired()])
    color = StringField(validators=[DataRequired()])
    email = StringField(validators=[
        Email(message='invalidate email')
    ])

class UpdatePasswordForm(BaseForm):
    oldpwd = StringField(validators=[DataRequired()])
    newpwd = StringField(validators=[DataRequired()])


class TokenForm(BaseForm):
  token = StringField(validators=[DataRequired()])

class UserInfoSearchForm(BaseForm):
    name = StringField()
    auth = StringField()


class RegisterForm(BaseForm):
    name = StringField(validators=[DataRequired()])
    password = StringField(validators=[DataRequired()])
    email = StringField(validators=[
        Email(message='invalidate email')
    ])
    gender = StringField(validators=[DataRequired()])
    age = IntegerField(validators=[DataRequired()])
    color = StringField(validators=[DataRequired()])