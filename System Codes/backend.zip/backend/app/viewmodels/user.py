from app.libs.enums import roles
from app.models.student import Student
from app.models.teacher import Teacher
from sqlalchemy import or_

class StudentViewModel(object):
    def __init__(self, stu):
        self.id = stu['id']
        self.name = stu['name']
        self.email = stu['email']
        self.age = stu['age']
        self.gender = stu['gender']
        self.color = stu['color']
        self.domain = "stu"

    def keys(self):
        return ['id', 'name','age', 'email', 'domain','gender','color']

    def __getitem__(self, item):
        return getattr(self, item)


class StudentCollection():
    def __init__(self):
        pass

    def fill(self, stus):
        self.stus = [StudentViewModel(stu) for stu in stus]

class TeacherViewModel(object):
    def __init__(self, tch):
        self.id = tch['id']
        self.name = tch['name']
        self.email = tch['email']
        self.gender = tch['gender']
        self.color = tch['color']
        self.domain = "tch"

    def keys(self):
        return ['id', 'name', 'email', 'domain','gender','color']

    def __getitem__(self, item):
        return getattr(self, item)


class TeacherCollection():
    def __init__(self):
        pass

    def fill(self, tchs):
        self.tchs = [TeacherViewModel(tch) for tch in tchs]