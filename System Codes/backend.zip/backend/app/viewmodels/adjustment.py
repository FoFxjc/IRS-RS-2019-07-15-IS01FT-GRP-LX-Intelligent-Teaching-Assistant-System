from collections import OrderedDict

from flask import g

from app.models.adjustment import Adjustment


class AdjustmentViewModel(object):
    def __init__(self, adjustment):
        self.id = adjustment['id']
        self.name = adjustment['name']
        self.key = adjustment['key']

    def keys(self):
        return ['id', 'name', 'key']

    def __getitem__(self, item):
        return getattr(self, item)


class AdjustmentCollection():
    def __init__(self):
        self.data = []

    def fill(self, adjustments):
        self.data = [AdjustmentViewModel(adjustment) for adjustment in adjustments]