from sqlalchemy import Column, String, Integer, orm, ForeignKey
from sqlalchemy.orm import relationship, backref
from sqlalchemy.dialects.mysql import LONGTEXT, DATE
from app.models.base import Base


class Calendar(Base):

    __tablename__ = 'calendar'

    id = Column(Integer, primary_key=True, autoincrement=True)
    stu_id = Column(Integer, ForeignKey('student.id'))
    student = relationship('Student', foreign_keys=[
        stu_id], backref=backref('Calendar'))
    course_id = Column(Integer, ForeignKey('course.id'))
    course = relationship('Course', foreign_keys=[
        course_id], backref=backref('Calendar'))
    start_date = Column(Integer, nullable=False)
    end_date = Column(Integer, nullable=False)
    type =  Column(String(30), nullable=False)
    status = Column(Integer, nullable=False)

    @orm.reconstructor
    def __init__(self):
        Base.__init__(self)
        self.fields = ['create_time', 'id', 'stu_id', 'type', 'start_date', 'end_date',
                       'course_id','status']