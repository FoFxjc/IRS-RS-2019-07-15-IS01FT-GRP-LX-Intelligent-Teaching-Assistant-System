import datetime
from collections import namedtuple

from sqlalchemy import Column, Integer, SmallInteger, String, inspect, orm
from werkzeug.security import check_password_hash, generate_password_hash

from app.libs.error_code import AuthFailed, NotFound
from app.models.base import Base, db

LoginResult = namedtuple(
    'LoginResult', ['status', 'error', 'data'])


class Teacher(Base):
    id = Column(Integer, primary_key=True)
    name = Column(String(20), unique=True, nullable=False)
    email = Column(String(50), unique=True, nullable=False)
    gender = Column(String(8), unique=True, nullable=False)
    color = Column(String(12), unique=True, nullable=False)
    _password = Column('password', String(100),nullable=True)

    @orm.reconstructor
    def __init__(self):
        self.fields = ['id', 'name', 'email','gender','color']

    @property
    def password(self):
      return self._password

    @password.setter
    def password(self, raw):
      self._password = generate_password_hash(raw)

    def check_password(self, raw):
      if not self._password:
        return False
      return check_password_hash(self._password, raw)

    @staticmethod
    def verify(name, password):
        tch = Teacher.query.filter_by(name=name).first_or_404()
        if not tch.check_password(password):
          return LoginResult(1, "Wrong Password", None)
        scope = 'tchScope'

        return LoginResult(0, "Login Success", {'uid': tch.id, 'scope': scope})
