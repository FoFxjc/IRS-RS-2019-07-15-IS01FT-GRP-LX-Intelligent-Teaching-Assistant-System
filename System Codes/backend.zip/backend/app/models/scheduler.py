from sqlalchemy import Column, String, Integer, orm, ForeignKey
from sqlalchemy.orm import relationship, backref
from sqlalchemy.dialects.mysql import LONGTEXT, DATE
from app.models.base import Base


class Scheduler(Base):

    __tablename__ = 'scheduler'

    id = Column(Integer, primary_key=True, autoincrement=True)
    cal_id = Column(Integer, ForeignKey('calendar.id'))
    calendar = relationship('Calendar', foreign_keys=[
        cal_id], backref=backref('Scheduler'))
    category = Column(String(30), nullable=False)
    start_date = Column(Integer, nullable=False)
    end_date = Column(Integer, nullable=False)
    detail = Column(LONGTEXT, nullable=False)
    status = Column(Integer, nullable=False)

    @orm.reconstructor
    def __init__(self):
        Base.__init__(self)
        self.fields = ['create_time', 'id', 'cal_id', 'category', 'start_date', 'end_date',
                       'detail','status']