from sqlalchemy import Column, String, Integer, orm, ForeignKey
from sqlalchemy.orm import relationship, backref
from sqlalchemy.dialects.mysql import LONGTEXT, DATE
from app.models.base import Base


class Course(Base):

    __tablename__ = 'course'

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(30), nullable=False)
    types = Column(LONGTEXT, nullable=False)
    start_date = Column(Integer, nullable=False)
    end_date = Column(Integer, nullable=False)
    classes_num_limited = Column(Integer, nullable=False)
    app_deadline = Column(Integer, nullable=False)
    tch_id = Column(Integer, ForeignKey('teacher.id'))
    teacher = relationship('Teacher', foreign_keys=[
        tch_id], backref=backref('Course'))
    tch_adjustments = Column(LONGTEXT)
    detail = Column(LONGTEXT, nullable=False)
    status = Column(Integer, nullable=False)

    @orm.reconstructor
    def __init__(self):
        Base.__init__(self)
        self.fields = ['create_time', 'id', 'name', 'types', 'start_date', 'end_date','classes_num_limited',
                       'tch_id', 'tch_adjustments', 'detail','status','app_deadline']