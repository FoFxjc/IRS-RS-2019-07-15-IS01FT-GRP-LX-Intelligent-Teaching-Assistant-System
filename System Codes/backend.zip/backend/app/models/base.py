"""
 Created by 七月 on 2018/5/11.
"""

__author__ = '七月'

"""
 Created by 七月 on 2018-3-11.
"""
from datetime import datetime

from flask_sqlalchemy import SQLAlchemy as _SQLAlchemy, BaseQuery
from sqlalchemy import Column, Integer, SmallInteger
from app.libs.error_code import NotFound
from contextlib import contextmanager
import time


class SQLAlchemy(_SQLAlchemy):
    @contextmanager
    def auto_commit(self):
        try:
            yield
            self.session.commit()
        except Exception as e:
            db.session.rollback()
            raise e


class Query(BaseQuery):
    def filter_by(self, **kwargs):
        if 'data_status' not in kwargs.keys():
            kwargs['data_status'] = 1
        return super(Query, self).filter_by(**kwargs)

    def get_or_404(self,ident):
        rv = self.get(ident)
        if not rv:
            raise NotFound()
        return rv

    def first_or_404(self):
        rv = self.first()
        if not rv:
            raise NotFound()
        return rv


db = SQLAlchemy(query_class=Query)


class Base(db.Model):
    __abstract__ = True
    create_time = Column(Integer)
    data_status = Column(SmallInteger, default=1, server_default='1')

    def __init__(self):
        if not self.create_time:
            self.create_time = int(datetime.now().timestamp())

    def __getitem__(self, item):
      return getattr(self,item)

    def set_attrs(self, attrs_dict):
        for key, value in attrs_dict.items():
            if hasattr(self, key) and key != 'id':
                setattr(self, key, value)

    def delete(self):
        self.data_status = 0

    def keys(self):
      return self.fields

    def hide(self, *keys):
      for key in keys:
        self.fields.remove(key)
      return self

    def append(self, *keys):
      for key in keys:
        self.fields.append(key)
      return self

