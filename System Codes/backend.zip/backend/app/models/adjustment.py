from sqlalchemy import Column, String, Integer, orm, ForeignKey
from sqlalchemy.orm import relationship, backref
from sqlalchemy.dialects.mysql import LONGTEXT, DATE
from app.models.base import Base


class Adjustment(Base):

    __tablename__ = 'adjustment'

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(30), nullable=False)
    key = Column(Integer, nullable=False)

    @orm.reconstructor
    def __init__(self):
        Base.__init__(self)
        self.fields = ['create_time', 'id', 'name', 'key']