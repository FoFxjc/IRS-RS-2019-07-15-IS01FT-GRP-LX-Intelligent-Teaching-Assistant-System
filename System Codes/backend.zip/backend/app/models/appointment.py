from sqlalchemy import Column, String, Integer, orm, ForeignKey
from sqlalchemy.orm import relationship, backref
from sqlalchemy.dialects.mysql import LONGTEXT, DATE
from app.models.base import Base
from app.libs.decisiontree import DecisionTree

class Appointment(Base):

    __tablename__ = 'appointment'

    id = Column(Integer, primary_key=True, autoincrement=True)
    course_id = Column(Integer, ForeignKey('course.id'))
    course = relationship('Course', foreign_keys=[
        course_id], backref=backref('Appointment'))
    type = Column(LONGTEXT, nullable=False)
    point_speaking = Column(String(20), nullable=False)
    point_reading = Column(String(20), nullable=False)
    point_writing = Column(String(20), nullable=False)
    point_listening = Column(String(20), nullable=False)
    point_total = Column(String(20), nullable=False)
    target_speaking = Column(String(20), nullable=False)
    target_reading = Column(String(20), nullable=False)
    target_writing = Column(String(20), nullable=False)
    target_listening = Column(String(20), nullable=False)
    target_total = Column(String(20), nullable=False)
    recommend_speaking = Column(Integer, nullable=False)
    recommend_reading = Column(Integer, nullable=False)
    recommend_writing = Column(Integer, nullable=False)
    recommend_listening = Column(Integer, nullable=False)
    stu_adjustments = Column(LONGTEXT, nullable=False)
    status = Column(Integer, nullable=False)
    stu_id = Column(Integer, ForeignKey('student.id'))
    student = relationship('Student', foreign_keys=[
        stu_id], backref=backref('Appointment'))

    @orm.reconstructor
    def __init__(self):
        Base.__init__(self)
        self.fields = ['create_time', 'id', 'course_id', 'type', 'point_speaking',
                       'point_reading','point_writing','point_listening','point_total',
                       'target_reading','target_writing','target_listening','target_total',
                       'recommend_speaking','recommend_reading','recommend_writing','recommend_listening',
                       'stu_id', 'stu_adjustments','status']


    def calculate_recommendation_point(module_point,module_target_point,stu,module_type,test_type):
        dt = DecisionTree(module_type,test_type)
        return dt.do_decision(module_point,module_target_point,stu)