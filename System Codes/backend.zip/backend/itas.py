"""
 Create by jiachenx on 2019/3/11
"""
from app import create_app
from app.libs.error import APIException
from werkzeug.exceptions import HTTPException
from app.libs.error_code import ServerError
from flask_script import Manager  # flask 脚本
from flask_migrate import Migrate, MigrateCommand  # flask 迁移数据
from app.models.base import db

__author__ = 'jiachenx'

app = create_app()
# migrate = Migrate(app, db)  # 传入2个对象一个是flask的app对象，一个是SQLAlchemy
# manager = Manager(app)
# manager.add_command('db', MigrateCommand)


# @manager.command
# def dev():
#     from livereload import Server
#     live_server = Server(app.wsgi_app)
#     live_server.watch('**/*.*')
#     live_server.serve(open_url=True)



@app.errorhandler(Exception)
def framework_error(e):
  if isinstance(e, APIException):
    return e
  if isinstance(e, HTTPException):
    code = e.code
    msg = e.description
    error_code = 1007
    return APIException(msg,code,error_code)
  else:
    # log
    if not app.config['DEBUG']:
      return ServerError()
    else:
      raise e

if __name__ == '__main__':
    app.run(host='0.0.0.0')
    # manager.run()
