<template>
  <el-card class="box-card-component" style="margin-left:8px;">
    <div slot="header" class="box-card-header">
      <img v-if="'tch' === roles" src="@/assets/teacher.jpg">
      <img v-if="'stu' === roles" src="@/assets/student.jpg">
    </div>
    <div style="position:relative;">
      <pan-thumb :image="userinfo.gender" :svg="true" class="panThumb"/>
      <mallki :text="userinfo.name" class-name="mallki-text"/>
      <div style="padding-top:35px;" class="progress-item">
        <span>Speaking</span>
        <el-progress :percentage="process.speaking"/>
      </div>
      <div class="progress-item">
        <span>Reading</span>
        <el-progress :percentage="process.reading"/>
      </div>
      <div class="progress-item">
        <span>Writing</span>
        <el-progress :percentage="process.writing"/>
      </div>
      <div class="progress-item">
        <span>Listening</span>
        <el-progress :percentage="process.listening"/>
      </div>
    </div>
  </el-card>
</template>

<script>
import { getInfo } from '@/api/user'
import { mapGetters } from 'vuex'
import PanThumb from '@/components/PanThumb'
import Mallki from '@/components/TextHoverEffect/Mallki'
import { getCalendar } from '@/api/calendar'
export default {
  components: { PanThumb, Mallki },
  filters: {
    statusFilter(status) {
      const statusMap = {
        success: 'success',
        pending: 'danger'
      }
      return statusMap[status]
    }
  },
  props: {
    calendarinfo: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      userinfo: {},
      process: {
        speaking: 0,
        listening: 0,
        writing: 0,
        reading: 0
      }
    }
  },
  computed: {
    ...mapGetters([
      'name',
      'id',
      'avatar',
      'roles'
    ])
  },
  watch: {
    calendarinfo: {
      handler(newValue, oldValue) {
        newValue.calendarList.forEach(element => {
          this.process[element['name'].toLowerCase()] = (element['total_class'] - element['remain_class']) * 100 / element['total_class']
        })
      },
      immediate: true,
      deep: true
    }
  },
  created() {
    this.initaldata()
  },
  methods: {
    initaldata() {
      getInfo().then(response => {
        this.userinfo = response
      })
      this.getPersonalCalendar()
    },
    getPersonalCalendar() {
      getCalendar().then(response => {
        response.calendarList.forEach(element => {
          this.process[element['name'].toLowerCase()] = (element['total_class'] - element['remain_class']) * 100 / element['total_class']
        })
      })
    }
  }

}
</script>

<style rel="stylesheet/scss" lang="scss" >
.box-card-component{
  .el-card__header {
    padding: 0px!important;
  }
}
</style>
<style rel="stylesheet/scss" lang="scss" scoped>
.status-wrapper {
    width: 100%;
    display:flex;
    flex-direction:column;
    justify-content:center;
    align-items:center;
    .button {
      display:flex;
      flex-direction:column;
      justify-content:center;
      align-items:center;
      width: 140px;
      height: 140px;
      text-align: center;
      border-radius: 50%;
      border: none;
      box-shadow: 0 2px 5px rgba(0, 0, 0, .4);
      background: -webkit-linear-gradient(top, #fff, #d5dbe1);
      background: -moz-linear-gradient(top, #fff, #d5dbe1);
      background: -ms-linear-gradient(top, #fff, #d5dbe1);
      background: -o-linear-gradient(top, #fff, #d5dbe1);
      -webkit-transition: all .13s ease-out;
      -moz-transition: all .13s ease-out;
      -o-transition: all .13s ease-out;
      transition: all .13s ease-out;
      .card-panel-icon-wrapper {
        display:flex;
        flex-direction:column;
        justify-content:center;
        align-items:center;
        width: 120px;
        height: 120px;
        text-align: center;
        border-radius: 50%;
        color: #fff;
        box-shadow: 0 2px 5px rgba(0, 0, 0, .4);
        background: -webkit-linear-gradient(top, #fff, #d5dbe1);
        background: -moz-linear-gradient(top, #fff, #d5dbe1);
        background: -ms-linear-gradient(top, #fff, #d5dbe1);
        background: -o-linear-gradient(top, #fff, #d5dbe1);
        .card-panel-icon {
          font-size: 60px;
        }
      }
      .card-panel-text {
        font-weight: bold;
      }
    }
}
.box-card-component {
  .box-card-header {
    position: relative;
    height: 220px;
    img {
      width: 100%;
      height: 100%;
      transition: all 0.2s linear;
      &:hover {
        transform: scale(1.1, 1.1);
        filter: contrast(130%);
      }
    }
  }
  .mallki-text {
    position: absolute;
    top: 0px;
    right: 0px;
    font-size: 20px;
    font-weight: bold;
  }
  .panThumb {
    z-index: 100;
    height: 70px!important;
    width: 70px!important;
    position: absolute!important;
    top: -45px;
    left: 0px;
    border: 5px solid #ffffff;
    background-color: #fff;
    margin: auto;
    box-shadow: none!important;
    /deep/ .pan-info {
      box-shadow: none!important;
    }
  }
  .progress-item {
    margin-bottom: 10px;
    font-size: 14px;
  }
  @media only screen and (max-width: 1510px){
    .mallki-text{
      display: none;
    }
  }
}
</style>
