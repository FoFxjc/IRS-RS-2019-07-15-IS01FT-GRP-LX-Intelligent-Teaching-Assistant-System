<template>
  <el-container class="calendar_container">
    <el-aside class="menu" width="150px">
      <div class="lnb-new-schedule" >
        <el-button type="button" class="lnb-new-schedule-btn move-today" data-action="move-today" @click="onClickNavi('today')">Today</el-button>
      </div>
      <div id="lnb-calendars" class="lnb-calendars">
        <div>
          <div class="lnb-calendars-item" style="text-align:center;">
            <label>
              <input ref="fullcalendar" class="tui-full-calendar-checkbox-square" type="checkbox" value="all" checked @click="showfullcalendar()">
              <span />
              View all
            </label>
          </div>
        </div>
        <div id="calendarList" class="lnb-calendars-d1" >
          <div v-for="calendar in calendarList" :key="calendar.id" class="lnb-calendars-item">
            <label>
              <input :value="calendar.id" type="checkbox" class="tui-full-calendar-checkbox-round" checked @click="onChangeNewScheduleCalendar($event)">
              <span :ref="'calender_icon_'+calendar.id" :style="{'border-color':calendar.borderColor,'background-color':calendar.borderColor}"/>
              <span>{{ calendar.name }}</span>
            </label>
          </div>
        </div>
      </div>
    </el-aside>
    <el-main>
      <div>
        <el-row class="toolbar" gutter="20">
          <el-col span="2">
            <el-select v-model="selectedView" @change="defaultviewChange">
              <el-option
                v-for="item in viewModeOptions"
                :key="item.value"
                :label="item.title"
                :value="item.value"
              />
            </el-select>
          </el-col>
          <el-col span="4">
            <el-button icon="el-icon-arrow-left" data-action="move-prev" circle @click="onClickNavi('prev')"/>
            <el-button icon="el-icon-arrow-right" style="margin-left:-1px;" data-action="move-next" circle @click="onClickNavi('next')" />
            <span class="render-range">{{ dateRange }}</span>
          </el-col>
          <el-col span="7">
            <el-checkbox :disabled="selectedView != 'month'" @change="showweedends">Show weekends</el-checkbox>
            <el-checkbox :disabled="selectedView != 'month'" @change="startweekonmonday">Start Week on Monday</el-checkbox>
            <el-checkbox :disabled="selectedView != 'month'" @change="narrowerthanweekdays">Narrower than weekdays</el-checkbox>
          </el-col>

        </el-row>
      </div>
      <component
        ref="tuiCal"
        :is="type"
        :use-detail-popup="useDetailPopup"
        :view="selectedView"
        :calendars="calendarList"
        :schedules="scheduleList"
        :theme="theme"
        :template="template"
        :task-view="taskView"
        :schedule-view="scheduleView"
        :month="month"
        :week="week"
        :timezones="timezones"
        :disable-dbl-click="disableDblClick"
        :is-read-only="isReadOnly"
        :use-creation-popup="useCreationPopup"
      />
    </el-main>
  </el-container>
</template>
<script>
import 'tui-time-picker/dist/tui-time-picker.css'
import 'tui-date-picker/dist/tui-date-picker.css'
import 'tui-calendar/dist/tui-calendar.css'
import { deepClone } from '@/utils/index'
import { Calendar } from '@toast-ui/vue-calendar'
import { getCalendarByCourse_id } from '@/api/calendar'
export default {
  name: 'App',
  components: {
    'calendar': Calendar
  },
  data() {
    return {
      viewModeOptions: [
        {
          title: 'Monthly',
          value: 'month'
        },
        {
          title: 'Weekly',
          value: 'week'
        },
        {
          title: 'Daily',
          value: 'day'
        }
      ],
      dateRange: '',
      selectedView: 'month',
      calendarList: [
      ],
      scheduleList: [
      ],
      timezones: [{
        timezoneOffset: 480,
        displayLabel: 'GMT+08:00',
        tooltip: 'Seoul'
      }],
      template: {
      },
      month: {
        startDayOfWeek: 0
      },
      week: {
        showTimezoneCollapseButton: true,
        timezonesCollapsed: true
      },
      taskView: false,
      scheduleView: true,
      useDetailPopup: true,
      disableDblClick: true,
      useCreationPopup: false,
      isReadOnly: true,
      type: ''
    }
  },
  watch: {
    selectedView(newValue) {
      this.$refs.tuiCal.invoke('changeView', newValue, true)
      this.setRenderRangeText()
    },
    scheduleList(newValue) {
      let fullcalendar = true
      newValue.forEach(element => {
        if (element.isVisible === false) {
          fullcalendar = false
        }
      })
      this.$refs.fullcalendar.checked = fullcalendar
    }
  },
  mounted() {
    const course_id = this.$route.query.course_id
    this.init(course_id)
  },
  methods: {
    init(course_id) {
      this.loadCalendar(course_id)
    },
    loadCalendar(course_id) {
      getCalendarByCourse_id(course_id).then(response => {
        this.calendarList = response.calendarList
        this.scheduleList = response.scheduleList
        this.type = 'calendar'
        setInterval(() => {
          this.setRenderRangeText()
        }, 200)
      })
    },
    showweedends(value) {
      if (value) {
        this.selectedView = 'month'
        this.month = {
          workweek: true // show only 5 days except for weekend
        }
      } else {
        this.month = {
          workweek: false // show only 5 days except for weekend
        }
      }
      this.setRenderRangeText()
    },
    startweekonmonday(value) {
      if (value) {
        this.selectedView = 'month'
        this.month = {
          startDayOfWeek: 1
        }
      } else {
        this.month = {
          startDayOfWeek: 0
        }
      }
      this.setRenderRangeText()
    },
    narrowerthanweekdays(value) {
      if (value) {
        this.selectedView = 'month'
        this.month = {
          narrowWeekend: true
        }
      } else {
        this.month = {
          narrowWeekend: false
        }
      }
      this.setRenderRangeText()
    },
    setRenderRangeText() {
      const { invoke } = this.$refs.tuiCal
      const view = invoke('getViewName')
      const calDate = invoke('getDate')
      const rangeStart = invoke('getDateRangeStart')
      const rangeEnd = invoke('getDateRangeEnd')
      let year = calDate.getFullYear()
      let month = calDate.getMonth() + 1
      let date = calDate.getDate()
      let dateRangeText = ''
      let endMonth, endDate, start, end
      switch (view) {
        case 'month':
          dateRangeText = `${year}.${month}`
          break
        case 'week':
          year = rangeStart.getFullYear()
          month = rangeStart.getMonth() + 1
          date = rangeStart.getDate()
          endMonth = rangeEnd.getMonth() + 1
          endDate = rangeEnd.getDate()
          start = `${year}.${month}.${date} `
          end = `${endMonth}-${endDate}`
          dateRangeText = `${start}.${end}`
          break
        default:
          dateRangeText = `${year}.${month}.${date}`
      }
      this.dateRange = dateRangeText
    },
    onClickNavi(event) {
      this.$refs.tuiCal.invoke(event)
      this.setRenderRangeText()
    },
    findCalendar(calendarId) {
      return this.calendarList.find(item => item.id === calendarId)
    },
    onChangeNewScheduleCalendar(event) {
      const remain_scheduleList = deepClone(this.scheduleList)
      if (!event.target.checked) {
        this.$refs['calender_icon_' + event.target.value][0].style.backgroundColor = 'white'
        remain_scheduleList.forEach(element => {
          if (Number(element.calendarId) === Number(event.target.value)) {
            element.isVisible = false
          }
        })
      } else {
        this.$refs['calender_icon_' + event.target.value][0].style.backgroundColor = this.findCalendar(Number(event.target.value)).borderColor
        remain_scheduleList.forEach(element => {
          if (Number(element.calendarId) === Number(event.target.value)) {
            element.isVisible = true
          }
        })
      }
      this.scheduleList = remain_scheduleList
    },
    showfullcalendar() {
      const remain_scheduleList = deepClone(this.scheduleList)
      if (this.$refs.fullcalendar.checked) {
        remain_scheduleList.forEach(element => {
          element.isVisible = true
          this.$refs['calender_icon_' + element.calendarId][0].style.backgroundColor = this.findCalendar(element.calendarId).borderColor
        })
      } else {
        remain_scheduleList.forEach(element => {
          element.isVisible = false
          this.$refs['calender_icon_' + element.calendarId][0].style.backgroundColor = 'white'
        })
      }
      this.scheduleList = remain_scheduleList
    }
  }
}
</script>
<style>
.menu {
  top: 49px;
  bottom: 0;
  border-right: 1px solid #d5d5d5;
  padding: 12px 10px;
  text-align: center;
  background: #fafafa;
}
.menu .label {
  margin-bottom: 0;
  cursor: pointer;
}
.lnb-new-schedule {
  padding: 6px 0px;
  padding-top: -6px;
  border-bottom: 1px solid #e5e5e5;
}

.lnb-new-schedule-btn {
  height: 100%;
  font-size: 14px;
  background-color: #ff6618;
  color: #ffffff;
  border: 0;
  border-radius: 25px;
  padding: 10px 20px;
  font-weight: bold;
}

.lnb-new-schedule-btn:hover {
  height: 100%;
  font-size: 14px;
  background-color: #e55b15;
  color: #ffffff;
  border: 0;
  border-radius: 25px;
  padding: 10px 20px;
  font-weight: bold;
}

.lnb-new-schedule-btn:active {
  height: 100%;
  font-size: 14px;
  background-color: #d95614;
  color: #ffffff;
  border: 0;
  border-radius: 25px;
  padding: 10px 20px;
  font-weight: bold;
}

.toolbar{
  padding-bottom: 5px;
}

.lnb-calendars > div {
  padding: 12px 6px;
  border-bottom: 1px solid #e5e5e5;
  font-weight: normal;
}

.lnb-calendars-d1 {
  padding-left: 8px;
}

.lnb-calendars-d1 label {
  font-weight: normal;
}

.lnb-calendars-item {
  min-height: 13px;
  line-height: 13px;
  padding: 8px 0;
  font-size: 14px;
  text-align: left;
}

.calendar{
  padding: 5px 6px;
}
.el-select .el-input__inner {

  width: 100px;

}
</style>
