<template>
  <div :style="{ background: bgColor} " class="operation-button" @mouseenter="enterStyle()" @mouseleave="leaveStyle()" @click="handleOpertionButtonClick(action)">
    <div :style="{ color: bgColor, background: iColor} " class="item-icon-wrapper">
      <svg-icon :icon-class="action" class-name="item-icon" />
    </div>
  </div>
</template>
<script>
export default {
  props: {
    action: {
      type: String,
      default: 'edit'
    }
  },
  data() {
    return {
      iColor: '#6cb0f3',
      bgColor: '#fff'
    }
  },
  methods: {
    enterStyle: function() {
      this.bgColor = this.iColor
      this.iColor = '#fff'
      this.textColor = '#fff'
    },
    leaveStyle: function() {
      this.iColor = this.bgColor
      this.bgColor = '#fff'
      this.textColor = 'rgba(0, 0, 0, 0.45)'
    },
    handleOpertionButtonClick: function(action) {
      this.$emit('handleOpertionButtonClick', action)
    }

  }
}
</script>
<style lang="scss" scoped>
.operation-button {
  background-color: transparent;
  width: 35px;
  height: 35px;
  border-radius: 50%;
  display: inline-block;
  cursor: pointer;
  .item-icon-wrapper{
    display:flex;
    flex-direction:column;
    justify-content:center;
    align-items:center;
    width: 35px;
    height: 35px;
    text-align: center;
    border-radius: 50%;
    transition: all 0.38s ease-out;
    // background: #36a3f7;
    // color: #fff;
    .item-icon {
      font-size: 16px;
    }
  }
}
</style>
