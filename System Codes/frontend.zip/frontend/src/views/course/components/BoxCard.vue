<template>
  <el-card class="box-card-component" style="margin-left:8px;">
    <div slot="header" class="box-card-header">
      <img src="@/assets/teacher.jpg">
    </div>
    <div style="position:relative;">
      <pan-thumb :image="tch_info.gender" :svg="true" class="panThumb"/>
      <mallki :text="tch_info.name" class-name="mallki-text"/>
      <div style="padding-top:35px;">
        <div class="info-item">
          <el-row :gutter="10">
            <el-col :span="10">
              <span class="label">Teacher ID</span>
            </el-col>
            <el-col :offset="2" :span="12">
              <el-tag>{{ tch_info.id }}</el-tag>
            </el-col>
          </el-row>
        </div>
        <div class="info-item">
          <el-row :gutter="10">
            <el-col :span="10">
              <span class="label">Teacher Name</span>
            </el-col>
            <el-col :offset="2" :span="12">
              <el-tag >{{ tch_info.name }}</el-tag>
            </el-col>
          </el-row>
        </div>
        <div class="info-item">
          <el-row :gutter="10">
            <el-col :span="10">
              <span class="label">Teacher Email</span>
            </el-col>
            <el-col :offset="2" :span="12">
              <el-tag >
                <a :href="'mailto:'+tch_info.email" style="color:blue;">
                  <i class="el-icon-message"/>
                </a>
              </el-tag>
            </el-col>
          </el-row>
        </div>
      </div>
  </div></el-card>
</template>

<script>
import { mapGetters } from 'vuex'
import PanThumb from '@/components/PanThumb'
import Mallki from '@/components/TextHoverEffect/Mallki'

export default {
  components: { PanThumb, Mallki },
  filters: {
    statusFilter(status) {
      const statusMap = {
        success: 'success',
        pending: 'danger'
      }
      return statusMap[status]
    }
  },
  props: {
    tch_info: {
      type: Object,
      default: function() { }
    }
  },
  data() {
    return {
      statisticsData: {
        article_count: 1024,
        pageviews_count: 1024
      }
    }
  },
  computed: {
    ...mapGetters([
      'name',
      'avatar',
      'roles'
    ])
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" >
.box-card-component{
  .el-card__header {
    padding: 0px!important;
  }
}
</style>
<style rel="stylesheet/scss" lang="scss" scoped>
.info-item{
  padding-top:10px;
  .label{
    font-weight: bold;
  }
}
.status-wrapper {
    width: 100%;
    display:flex;
    flex-direction:column;
    justify-content:center;
    align-items:center;
    .button {
      display:flex;
      flex-direction:column;
      justify-content:center;
      align-items:center;
      width: 140px;
      height: 140px;
      text-align: center;
      border-radius: 50%;
      border: none;
      box-shadow: 0 2px 5px rgba(0, 0, 0, .4);
      background: -webkit-linear-gradient(top, #fff, #d5dbe1);
      background: -moz-linear-gradient(top, #fff, #d5dbe1);
      background: -ms-linear-gradient(top, #fff, #d5dbe1);
      background: -o-linear-gradient(top, #fff, #d5dbe1);
      -webkit-transition: all .13s ease-out;
      -moz-transition: all .13s ease-out;
      -o-transition: all .13s ease-out;
      transition: all .13s ease-out;
      .card-panel-icon-wrapper {
        display:flex;
        flex-direction:column;
        justify-content:center;
        align-items:center;
        width: 120px;
        height: 120px;
        text-align: center;
        border-radius: 50%;
        color: #fff;
        box-shadow: 0 2px 5px rgba(0, 0, 0, .4);
        background: -webkit-linear-gradient(top, #fff, #d5dbe1);
        background: -moz-linear-gradient(top, #fff, #d5dbe1);
        background: -ms-linear-gradient(top, #fff, #d5dbe1);
        background: -o-linear-gradient(top, #fff, #d5dbe1);
        .card-panel-icon {
          font-size: 60px;
        }
      }
      .card-panel-text {
        font-weight: bold;
      }
    }
}
.box-card-component {
  .box-card-header {
    position: relative;
    height: 220px;
    img {
      width: 100%;
      height: 100%;
      transition: all 0.2s linear;
      &:hover {
        transform: scale(1.1, 1.1);
        filter: contrast(130%);
      }
    }
  }
  .mallki-text {
    position: absolute;
    top: 0px;
    right: 0px;
    font-size: 20px;
    font-weight: bold;
    text-transform: capitalize;
  }
  .panThumb {
    z-index: 100;
    height: 70px!important;
    width: 70px!important;
    position: absolute!important;
    top: -45px;
    left: 0px;
    border: 5px solid #ffffff;
    background-color: #fff;
    margin: auto;
    box-shadow: none!important;
    /deep/ .pan-info {
      box-shadow: none!important;
    }
  }
  .progress-item {
    margin-bottom: 10px;
    font-size: 14px;
  }
  @media only screen and (max-width: 1510px){
    .mallki-text{
      display: none;
    }
  }
}
</style>
