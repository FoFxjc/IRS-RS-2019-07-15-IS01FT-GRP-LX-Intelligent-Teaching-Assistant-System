<template>
  <div class="page-container">
    <el-row :gutter="20">
      <el-col :span="18">
        <el-card class="box-card" shadow="always" style="min-height:700px;">
          <div slot="header" class="clearfix head-title">
            <div class="head-text" style="font-size:20px;margin-top:5px;">
              Course
              <el-select v-model="displayIndex" placeholder="Course ID" style="width: 60px;" size="small" class="filter-item" @change="handleFilter">
                <el-option v-for="(item,index) in courses" :key="index" :label="item.id" :value="index"/>
              </el-select>
            </div>
            <div
              class="action-wrapper"
            >
              <el-tooltip class="item" effect="dark" content="My scheduler" placement="top-start">
                <operation-button v-show="displayCourse.status == 4 && Object.keys(appointment).length !== 0" action="schedule" style="margin-left:5px;" @handleOpertionButtonClick="handleOpertionButtonClick"/>
              </el-tooltip>

            </div>
          </div>
          <el-form ref="course_form" label-position="left" label-width="200px" style="margin: 5px 0px 5px 10px;">
            <el-row :gutter="20">
              <el-col :span="10" label-width="100px">
                <el-form-item label="Course ID">
                  <el-input :rows="1" :value="displayCourse.id" class="article-input" readonly/>
                </el-form-item>
              </el-col>
              <el-col :span="14">
                <el-form-item label="Course Name">
                  <el-input :rows="1" :value="displayCourse.name" class="article-input" readonly/>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row :gutter="20">
              <el-col :span="10">
                <el-form-item label="Course Type">
                  <el-tag v-for="(item,index) of displayCourse.types" :key="index" style="margin:auto 4px;text-transform:Uppercase;">{{ item }}</el-tag>
                </el-form-item>
              </el-col>
              <el-col :span="10">
                <el-form-item label="Deadline for appointment">
                  <el-input :rows="1" :value="displayCourse.app_deadline" class="article-input" readonly/>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row :gutter="20">
              <el-col :span="10">
                <el-form-item label="Course Range">
                  <div style="text-aligh:center;padding-left:15px;font-size:16px;border-bottom:1px solid lightgray;">
                    <span>{{ displayCourse.start_date }}</span>
                    <i class="el-icon-minus" />
                    <span>{{ displayCourse.end_date }}</span>
                  </div>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row :gutter="20">
              <el-col :span="14">
                <el-form-item label="Teacher's Adjustments">
                  <el-tag v-for="(item,index) of displayCourse.tch_adjustments" :key="index" style="margin:auto 4px;">{{ item.name }}</el-tag>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row :gutter="20">
              <el-col :span="14">
                <el-form-item label="Course Status">
                  <el-tag v-show="displayCourse.status == 4" type="success" >Done Scheduling</el-tag>
                  <el-tag v-show="displayCourse.status == 3" type="warning" >Scheduling</el-tag>
                  <el-tag v-show="displayCourse.status == 2" type="danger" >Stopped Collection</el-tag>
                  <el-tag v-show="displayCourse.status == 1" type="warning" >Collecting Appointments</el-tag>
                  <el-tag v-show="displayCourse.status == 0" type="info" >Waiting to Start</el-tag>
                </el-form-item>
              </el-col>
            </el-row>
            <el-divider/>
            <el-row :gutter="20">
              <h4 style="margin-top:0px;">Course Introduction</h4>
              <div class="editor-content" v-html="displayCourse.detail"/>
            </el-row>
          </el-form>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-row>
          <box-card :tch_info="displayCourse.tch"/>
        </el-row>
        <el-row style="margin-top:20px;">
          <el-card class="box-card appointment_info" style="min-height:300px;">
            <div slot="header" class="clearfix head-title">
              <div class="head-text">
                My Appointment
              </div>
              <div
                class="action-wrapper"
                @click="handleAppointmentCreate"
              >
                <svg-icon v-if="Object.keys(appointment).length == 0" icon-class="add" class-name="item-icon"/>
                <svg-icon v-else icon-class="edit" class-name="item-icon"/>
              </div>
            </div>
            <div v-if="Object.keys(appointment).length == 0" class="card_body-container">
              <div
                style="height:200px;text-align:center;
            text-shadow: 0.5px 0.5px 0.5px #000, -1px -1px 1px #fff;background:rgba(160, 160, 160);filter:alpha(opacity=50);-moz-opacity:0.5;opacity:0.5; ">
                <div style="line-height: 100px;height:100px;cursor:pointer;" @click="handleAppointmentCreate">
                  Add an appointment
                </div>
              </div>
            </div>
            <div v-else style="background:white;padding: 5px;border: 1px solid lightgray;">
              <el-divider content-position="left">
                <span style="font-weight:bold">Appointment ID: {{ appointment.id }}</span>
              </el-divider>
              <div class="info-item">
                <el-row :gutter="10">
                  <el-col :span="10" >
                    <div class="label">Status:</div>
                  </el-col>
                  <el-col :span="12">
                    <el-tag v-show="appointment.status == 2" type="success" >Approved</el-tag>
                    <el-tag v-show="appointment.status == 1" type="warning" >Waiting</el-tag>
                    <el-tag v-show="appointment.status == 0" type="error" >Close</el-tag>
                  </el-col>
                </el-row>
              </div>
              <div class="info-item">
                <el-row :gutter="10">
                  <el-col :span="10" >
                    <div class="label">Listening</div>
                  </el-col>
                  <el-col :span="12">
                    <el-tag>{{ appointment.recommend_listening }}</el-tag>
                  </el-col>
                </el-row>
              </div>
              <div class="info-item">
                <el-row :gutter="10">
                  <el-col :span="10">
                    <div class="label">Reading</div>
                  </el-col>
                  <el-col :span="12">
                    <el-tag>{{ appointment.recommend_reading }}</el-tag>
                  </el-col>
                </el-row>
              </div>
              <div class="info-item">
                <el-row :gutter="10">
                  <el-col :span="10">
                    <div class="label">Writing</div>
                  </el-col>
                  <el-col :span="12">
                    <el-tag>{{ appointment.recommend_writing }}</el-tag>
                  </el-col>
                </el-row>
              </div>
              <div class="info-item">
                <el-row :gutter="10">
                  <el-col :span="10">
                    <div class="label">Speaking</div>
                  </el-col>
                  <el-col :span="12">
                    <el-tag>{{ appointment.recommend_speaking }}</el-tag>
                  </el-col>
                </el-row>
              </div>
            </div>
          </el-card>
        </el-row>
      </el-col>
    </el-row>
  </div>
</template>
<script>
import OperationButton from './components/OperationButton'
import BoxCard from './components/BoxCard'
import { getCourseList, askforsch } from '@/api/course'
import { getAppointmentBySidCid } from '@/api/appointment'
export default {
  name: 'DashboardAdmin',
  components: {
    BoxCard,
    OperationButton
  },
  data() {
    return {
      courses: [],
      displayIndex: 0,
      appointment: {}
    }
  },
  computed: {
    displayCourse() {
      let coursedata = {}
      if (this.courses.length !== 0) {
        coursedata = this.courses[this.displayIndex]
      }
      return coursedata
    }
  },
  created() {
    this.loadCoursesData()
  },
  methods: {
    handleFilter() {
      getAppointmentBySidCid(this.$store.getters.id, this.courses[this.displayIndex].id).then(response => {
        this.appointment = response
      })
    },
    loadCoursesData() {
      getCourseList().then(response => {
        this.courses = response
        getAppointmentBySidCid(this.$store.getters.id, this.courses[this.displayIndex].id).then(response => {
          this.appointment = response
        })
      })
    },
    handleEdit() {
      this.$router.push({
        path: '/course/edit/',
        query: {
          title: 'Edit-Course-' + this.selectedcourse.id,
          action: 'Edit',
          id: this.selectedcourse.id
        }
      })
    },
    handleAppointmentCreate() {
      if (this.displayCourse.status > 3) {
        this.$message({
          type: 'warning',
          message: 'The Appointments Collection of this course is close!'
        })
      } else if (Object.keys(this.appointment).length === 0) {
        this.$router.push({
          path: '/course/appointment/',
          query: {
            title: 'Add-Appointment',
            action: 'create',
            course_id: this.courses[this.displayIndex].id
          }
        })
      } else {
        this.$router.push({
          path: '/course/appointment/',
          query: {
            title: 'Edit-Appointment-' + this.appointment.id,
            action: 'edit',
            appointment_id: this.appointment.id
          }
        })
      }
    },
    handleOpertionButtonClick(action) {
      askforsch(this.displayCourse.id).then(response => {
        if (response.error_code === 0) {
          this.$notify({
            title: 'Success',
            message: 'The Scheduling Process is done!',
            type: 'success'
          })
          this.$router.push({
            path: '/course/schedulers/',
            query: {
              title: 'Course-' + this.displayCourse.id,
              course_id: this.displayCourse.id
            }
          })
        } else {
          this.$message({
            type: 'warning',
            message: 'Still Scheduling, Please wait a moment!'
          })
          return false
        }
      })
    },
    handleSearchAppointment() {
      this.$router.push({
        path: '/course/appointments_tch/'
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.page-container {
  padding: 25px;
  height: 100%;
  background: rgb(240, 242, 245);
}
.box-card /deep/ .el-card__header {
  background: rgb(108, 176, 243);
  color:rgb(255, 255, 255);
  border: 0px;
  border-radius: 0px;
  border-top-right-radius:5px;
  border-top-left-radius:5px;
}
.box-card /deep/ .el-card__body {
  border-radius: 0px;
  border-bottom-right-radius:5px;
  border-bottom-left-radius:5px;
  background-color: transparent;
}
.box-card {
  border: 0px;
  margin: 5px;
  background-color: transparent;
  .head-title {
    margin-top: 0px;
    .head-text {
      display: inline-block;
      vertical-align: middle;
      padding-left: 10px;
    }
    .action-wrapper {
      float: right;
      vertical-align: middle;
      .item-icon {
        font-size: 22px;
        cursor:pointer;
        }
    }
  }

  .card_body-container {
    transition: min-width .5s;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.4);
    padding: 0px;
  }
}
.el-divider{
  margin-top: 12px;
}
.info-item{
  padding: 5px 10px;
  padding-left: 40px;
  .label{
    font-weight: 300;
    padding-top: 5px;
  }
}
</style>
