<template>
  <div class="form-container">
    <el-card class="box-card form-wrapper">
      <el-form ref="form" :model="form" :rules="rules" label-position="left" label-width="200px" style="margin: 30px 0;">
        <div v-show="stepsstatus == 0" ref="step1" class="step">
          <h1 class="step-title">Course Info</h1>
          <el-divider />
          <div style="margin-top:10px;">
            <el-row v-show="form.id">
              <el-col :span="10">
                <el-form-item label="Course ID" prop="id">
                  <el-input :rows="1" v-model="form.id" class="article-input" placeholder="Course ID" readonly=""/>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="10">
                <el-form-item label="Course Name" prop="name">
                  <el-input :rows="1" v-model="form.name" class="article-input" placeholder="Course Name" clearable/>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="10">
                <el-form-item label="Course including Type" prop="types">
                  <el-checkbox-group v-model="form.types">
                    <el-checkbox label="IELTS" border/>
                    <el-checkbox label="TOEFL" border/>
                  </el-checkbox-group>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="10">
                <el-form-item label="Teacher" prop="tch_name">
                  <el-input :rows="1" v-model="form.tch_name" class="article-input" placeholder="Teacher Name" readonly=""/>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-form-item label="Course Range" prop="course_range">
                <el-date-picker
                  v-model="form.course_range"
                  :picker-options="pickerOptions"
                  type="daterange"
                  range-separator="-"
                  value-format="yyyy.MM.dd"
                  start-placeholder="Start Date"
                  end-placeholder="End Date"/>
              </el-form-item>
            </el-row>
            <el-row>
              <el-form-item label="Appointment Deadline" prop="app_deadline">
                <el-date-picker
                  v-model="form.app_deadline"
                  :picker-options="pickerOptions"
                  value-format="yyyy.MM.dd"
                  type="datetime"
                  placeholder="Deadline"/>
              </el-form-item>
            </el-row>
          </div>
        </div>
        <div v-show="stepsstatus == 1" ref="step2" class="step">
          <h1 class="step-title">Personal Adjustments</h1>
          <el-divider content-position="left"/>
          <el-form-item prop="personal_adjustments">
            <el-transfer
              v-model="form.personal_adjustments"
              :data="loaddata.adjustments"
              :titles="['Available', 'Selected']"
              :format="{
                noChecked: '${total}',
                hasChecked: '${checked}/${total}'
              }"
            />
          </el-form-item>
        </div>
        <div v-show="stepsstatus == 2" ref="step3" class="step">
          <h1 class="step-title">Course Introduction</h1>
          <tinymce :height="300" v-model="form.detail"/>
        </div>
        <div v-show="stepsstatus == 3" ref="step3" class="comfirm-step">
          <h1 class="step-title">Confirm info</h1>
          <el-divider content-position="left"/>
          <div style="margin-top:20px;">
            <el-row>
              <el-col :span="12">
                <el-form label-position="right" label-width="180px">
                  <el-row v-show="form.id">
                    <el-col :span="18">
                      <el-form-item label="Course ID">
                        <el-input :value="form.id" :rows="1" class="article-input" placeholder="Empty" readonly/>
                      </el-form-item>
                    </el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="18">
                      <el-form-item label="Course Name">
                        <el-input :rows="1" :value="form.name" class="article-input" placeholder="Empty" readonly/>
                      </el-form-item>
                    </el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="18">
                      <el-form-item label="Course including Type">
                        <el-tag v-for="(item,index) of form.types" :key="index" style="margin:auto 4px;text-transform:Uppercase;">{{ item }}</el-tag>
                      </el-form-item>
                    </el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="18">
                      <el-form-item label="Teacher">
                        <el-input :rows="1" :value="form.tch_name" class="article-input" placeholder="Empty" readonly/>
                      </el-form-item>
                    </el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="18">
                      <el-form-item label="Course Range">
                        <div style="text-aligh:center;padding-left:15px;font-size:16px;border-bottom:1px solid lightgray;">
                          <span>{{ form.course_range[0] }}</span>
                          <i class="el-icon-minus" />
                          <span>{{ form.course_range[1] }}</span>
                        </div>
                      </el-form-item>
                    </el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="18">
                      <el-form-item label="Appointment Deadline">
                        <div style="text-aligh:center;padding-left:15px;font-size:16px;border-bottom:1px solid lightgray;">
                          <span>{{ form.app_deadline }}</span>
                        </div>
                      </el-form-item>
                    </el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="18">
                      <el-form-item label="Classes Num Limitation" prop="classes_num_limited">
                        <el-input v-show="form.classes_num_limited !== 0" v-model="form.classes_num_limited" class="article-input" style="width:100px;" placeholder="Empty" readonly/>
                        <el-button v-show="form.classes_num_limited == 0 || classes_nums_change" icon="el-icon-refresh" circle="" @click="getClassesNum()"/>
                      </el-form-item>
                    </el-col>
                  </el-row>
                </el-form>
              </el-col>
              <el-col :span="12">
                <el-form :inline="true" label-position="right">
                  <el-divider content-position="left">Personal Adjustments</el-divider>
                  <el-tag v-for="(item,index) of showAdjustment" :key="index" style="margin:auto 4px;">{{ item }}</el-tag>
                  <el-divider content-position="left">Introduction</el-divider>
                  <div class="editor-content" v-html="form.detail"/>
                </el-form>
              </el-col>
            </el-row>
          </div>
        </div>
      </el-form>
      <div class="bottom clearfix">
        <el-button v-show="haspreStep" icon="el-icon-arrow-left" style="float:left;margin: 5px;" @click="preStep()">preStep</el-button>
        <el-button v-show="hasnextStep" style="float:right;margin: 5px;" @click="nextStep()">
          nextStep
          <i class="el-icon-arrow-right el-icon--right"/>
        </el-button>
        <el-button v-show="!hasnextStep" style="float:right;margin: 5px;" @click="closeCurrentView()">Cancel</el-button>
        <el-button v-show="!hasnextStep && !form.id" type="primary" style="float:right;margin: 5px;" @click="handleSubmit()">Submit</el-button>
        <el-button v-show="!hasnextStep && form.id" type="primary" style="float:right;margin: 5px;" @click="updateInfo()">Save</el-button>
      </div>

    </el-card>
  </div>
</template>
<script>
import MDinput from '@/components/MDinput'
import bus from '@/assets/eventBus'
import Tinymce from '@/components/Tinymce'
import { getAdjustments } from '@/api/adjustment'
import { updateCourseInfo, getCourseList, getTotalClassNum } from '@/api/course'
export default {
  components: {
    MDinput,
    Tinymce
  },
  data() {
    var validateDeadline = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('Please enter the Deadline of Appoinments Collections'))
      } else if ((new Date(value)) > (new Date(this.form.course_range[0]))) {
        callback(new Error('The deadline must before the start date of this course'))
      } else {
        callback()
      }
    }
    var validateNumOfAdjustments = (rule, value, callback) => {
      if (value.length > 2) {
        callback(new Error(`Can't choose more than two adjustments`))
      } else {
        callback()
      }
    }
    return {
      stepslength: 100,
      stepsstatus: 0,
      global_disabled: false,
      beacon_disabled: true,
      loaddata: {
        adjustments: []
      },
      pickerOptions: {
        disabledDate(time) {
          return time.getTime() < Date.now() - 8.64e7
        }
      },
      classes_nums_change: true,
      form: {
        id: '',
        name: '',
        types: ['IELTS', 'TOEFL'],
        tch_name: this.$store.getters.name,
        course_range: [],
        app_deadline: '',
        classes_num_limited: 0,
        personal_adjustments: [],
        detail: ''
      },
      predata: {},
      rules: {
        name: [
          { required: true, message: 'Pleace enter Course Name', trigger: 'blur' }
        ],
        types: [
          { type: 'array', required: true, message: 'Pleace choose course including type', trigger: 'change' }
        ],
        tch_name: [
          { required: true, message: 'Pleace enter name of teacher', trigger: 'blur' }
        ],
        course_range: [
          { required: true, message: 'Pleace choose the course range', trigger: 'change' }
        ],
        app_deadline: [
          { validator: validateDeadline, trigger: 'blur' }
        ],
        intro: [
          { required: true, message: 'Pleace enter the student limitation', trigger: 'change' }
        ],
        personal_adjustments: [
          { validator: validateNumOfAdjustments, trigger: 'change' }
        ],
        classes_num_limited: [
          { required: true, message: 'Pleace generate or refresh your Classes Num Limitaion', trigger: 'blur' }
        ]
      },
      validlist: [
        ['name', 'types', 'tch_name', 'course_range', 'app_deadline'],
        ['personal_adjustments'],
        ['intro'],
        ['classes_num_limited']
      ]
    }
  },
  computed: {
    showAdjustment: function() {
      const displayData = []
      this.form.personal_adjustments.forEach((item, index) => {
        this.loaddata.adjustments.forEach((o_item, o_index) => {
          if (item === o_item.key) {
            displayData.push(o_item.label)
          }
        })
      })
      return displayData
    },
    hasnextStep: function() {
      if (this.stepsstatus < this.stepslength - 1 && this.stepsstatus >= 0) {
        return true
      }
      if (this.stepsstatus === this.stepslength - 1) {
        return false
      }
    },
    haspreStep: function() {
      if (this.stepsstatus <= this.stepslength - 1 && this.stepsstatus > 0) {
        return true
      }
      if (this.stepsstatus === 0) {
        return false
      }
    },
    course_range: function() {
      return this.form.course_range
    },
    personal_adjustments: function() {
      return this.form.personal_adjustments
    }
  },
  watch: {
    course_range() {
      this.classes_nums_change = true
    },
    personal_adjustments() {
      this.classes_nums_change = true
    }
  },
  created() {
    this.loadPersonalAdjustment()
    if (this.$route.query.action === 'Edit') {
      const id = this.$route.query.id
      this.loadCourseInfo(id)
    }
    this.tempRoute = Object.assign({}, this.$route)
  },
  mounted() {
    const thiscp = this
    bus.$on('sendAddRepoStepStatus', function(stepstatus) {
      thiscp.stepslength = stepstatus.length
      thiscp.stepsstatus = stepstatus.status
    })
  },
  methods: {
    getClassesNum() {
      const classesNumUpdate = {}
      classesNumUpdate.start_date = this.form.course_range[0]
      classesNumUpdate.end_date = this.form.course_range[1]
      classesNumUpdate.adjustments = this.form.personal_adjustments
      getTotalClassNum(classesNumUpdate).then(response => {
        this.form.classes_num_limited = response.totalClassNum
        this.classes_nums_change = false
      })
    },
    loadPersonalAdjustment() {
      getAdjustments().then(response => {
        const ad_data = []
        response.forEach((item, index) => {
          ad_data.push({
            key: item.id,
            label: item.name
          })
        })
        this.loaddata.adjustments = ad_data
      })
    },
    updateInfo() {
      this.$refs.form.validate((valid) => {
        if (valid) {
          this.$confirm('Save', 'Confirm', {
            confirmButtonText: 'Save',
            cancelButtonText: 'Cancel',
            type: 'warning'
          })
            .then(() => {
              const updateinfo = this.form
              updateinfo.start_date = updateinfo.course_range[0]
              updateinfo.end_date = updateinfo.course_range[1]
              updateCourseInfo(updateinfo).then(response => {
                if (response.error_code === 0) {
                  this.$message({
                    type: 'success',
                    message: 'Save Success!'
                  })
                  this.closeCurrentView()
                } else {
                  return false
                }
              })
                .catch(err => {
                  console.log(err)
                })
            })
            .catch(() => {
              this.$message({
                type: 'info',
                message: 'Cancel Submission'
              })
            })
        }
      })
    },
    handleSubmit() {
      this.$refs.form.validate((valid) => {
        if (valid) {
          this.$confirm('Do your want to create this course?', 'Confirm', {
            confirmButtonText: 'Confirm',
            cancelButtonText: 'Cancel',
            type: 'warning'
          })
            .then(() => {
              const updateinfo = this.form
              updateinfo.start_date = updateinfo.course_range[0]
              updateinfo.end_date = updateinfo.course_range[1]
              updateCourseInfo(updateinfo).then(response => {
                if (response.error_code === 0) {
                  this.$message({
                    type: 'success',
                    message: 'Save Success!'
                  })
                  this.closeCurrentView()
                } else {
                  return false
                }
              })
                .catch(err => {
                  console.log(err)
                })
            })
            .catch(() => {
              this.$message({
                type: 'info',
                message: 'Cancel Submission'
              })
            })
        }
      })
    },
    isActive(route) {
      return route.path === this.$route.path
    },
    closeCurrentView() {
      const view = this.$route
      this.$store.dispatch('delView', view).then(({ visitedViews }) => {
        if (this.isActive(view)) {
          const latestView = visitedViews.slice(-1)[0]
          if (latestView) {
            this.$router.push(latestView)
          } else {
            this.$router.push('/')
          }
        }
      })
    },
    loadCourseInfo(id) {
      getCourseList(id).then(response => {
        console.log(response[0])
        const _currentcourse = response[0]
        this.form.id = _currentcourse.id
        this.form.name = _currentcourse.name
        this.form.type = _currentcourse.types
        this.form.tch_name = _currentcourse.tch.name
        this.form.course_range = [_currentcourse.start_date, _currentcourse.end_date]
        this.form.app_deadline = _currentcourse.app_deadline
        this.form.stu_limitation = _currentcourse.stu_num_limited
        const _tch_ad_data = []
        _currentcourse.tch_adjustments.forEach((item, index) => {
          _tch_ad_data.push(item.id)
        })
        this.form.personal_adjustments = _tch_ad_data
        this.form.detail = _currentcourse.detail
      })
    },
    validate_props(props) {
      let vaildpass = true
      props.forEach((prop, index) => {
        this.$refs.form.validateField(prop, (valid) => {
          if (valid) {
            vaildpass = false
          }
        })
      })
      return vaildpass
    },
    nextStep() {
      let ispass = true
      if (this.stepsstatus < this.stepslength) {
        ispass = this.validate_props(this.validlist[this.stepsstatus])
        if (ispass) {
          bus.$emit('nextAddRepoStep', 'next')
        } else {
          this.$message({
            message: 'Please complete the form.',
            type: 'error'
          })
        }
      }
    },
    preStep() {
      bus.$emit('preAddRepoStep', 'pre')
    }
  }
}
</script>
<style rel="stylesheet/scss" lang="scss">
.form-container {
  min-height: 500px;
  .form-wrapper {
    position: relative;
    margin-top: 14px;
    min-height: 500px;
    .bottom {
      border-top: 2px solid hsla(0, 0%, 90%, 0.5);
      position: absolute;
      width: 100%;
      bottom: 0;
      left: 0;
      line-height: 20px;
    }
    .step-title {
      line-height: 10px;
      padding-bottom: 5px;
    }
  }
}
.el-transfer {
  width: 800px !important;
}
.el-transfer-panel {
  width: 250px !important;
}
.clearfix:before,
.clearfix:after {
  display: table;
  content: '';
}
.clearfix:after {
  clear: both;
}
</style>

