<template>
  <div class="page-container">
    <el-row :gutter="20">
      <el-col :span="18">
        <el-card class="box-card" shadow="always" style="min-height:650px;">
          <div slot="header" class="clearfix head-title">
            <div class="head-text" style="font-size:20px;margin-top:5px;">
              Course
              <el-select v-model="displayIndex" placeholder="Course ID" style="width: 60px" size="small" class="filter-item" @change="handleFilter">
                <el-option v-for="(item,index) in courses" :key="index" :label="item.id" :value="index"/>
              </el-select>
            </div>
            <div
              class="action-wrapper"
            >
              <el-tooltip class="item" effect="dark" content="Add another Course" placement="top-start">
                <operation-button action="add" style="margin-left:5px;" @handleOpertionButtonClick="handleOpertionButtonClick"/>
              </el-tooltip>
              <el-tooltip v-show="displayCourse.status == 0 && displayCourse.status != 4" class="item" effect="dark" content="Start Collection for appointemnts" placement="top-start">
                <operation-button action="start" style="margin-left:5px;" @handleOpertionButtonClick="handleOpertionButtonClick"/>
              </el-tooltip>
              <el-tooltip v-show="displayCourse.status != 4 && displayCourse.status != 3" class="item" effect="dark" content="Edit Course Info" placement="top-start">
                <operation-button action="edit" style="margin-left:5px;" @handleOpertionButtonClick="handleOpertionButtonClick"/>
              </el-tooltip>
              <el-tooltip v-show="displayCourse.status == 1" class="item" effect="dark" content="Stop Appointment" placement="top-start">
                <operation-button action="stop" style="margin-left:5px;" @handleOpertionButtonClick="handleOpertionButtonClick"/>
              </el-tooltip>
              <el-tooltip v-show="displayCourse.status == 2" class="item" effect="dark" content="Do scheduling" placement="top-start">
                <operation-button action="doschedule" style="margin-left:5px;" @handleOpertionButtonClick="handleOpertionButtonClick"/>
              </el-tooltip>
              <el-tooltip v-show="displayCourse.status == 3 || displayCourse.status == 4" class="item" effect="dark" content="Check Calendar" placement="top-start">
                <operation-button action="schedule" style="margin-left:5px;" @handleOpertionButtonClick="handleOpertionButtonClick"/>
              </el-tooltip>
            </div>
          </div>
          <div>
            <el-form ref="course_form" label-position="left" label-width="200px" style="margin: 5px 0px 5px 10px;">
              <el-row :gutter="20">
                <el-col :span="10" label-width="100px">
                  <el-form-item label="Course ID">
                    <el-input :rows="1" :value="displayCourse.id" class="article-input" readonly/>
                  </el-form-item>
                </el-col>
                <el-col :span="14">
                  <el-form-item label="Course Name">
                    <el-input :rows="1" :value="displayCourse.name" class="article-input" readonly/>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row :gutter="20">
                <el-col :span="10">
                  <el-form-item label="Course Type">
                    <el-tag v-for="(item,index) of displayCourse.types" :key="index" style="margin:auto 4px;text-transform:Uppercase;">{{ item }}</el-tag>
                  </el-form-item>
                </el-col>
                <el-col :span="10">
                  <el-form-item label="Deadline for appointment">
                    <el-input :rows="1" :value="displayCourse.app_deadline" class="article-input" readonly/>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row :gutter="20">
                <el-col :span="10">
                  <el-form-item label="Course Range">
                    <div style="text-aligh:center;padding-left:15px;font-size:16px;border-bottom:1px solid lightgray;">
                      <span>{{ displayCourse.start_date }}</span>
                      <i class="el-icon-minus" />
                      <span>{{ displayCourse.end_date }}</span>
                    </div>
                  </el-form-item>
                </el-col>
                <el-col :span="10">
                  <el-form-item label="Classes Number Limitation">
                    <el-input :rows="1" :value="displayCourse.classes_num_limited" class="article-input" readonly/>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row :gutter="20">
                <el-col :span="14">
                  <el-form-item label="Personal Adjustment">
                    <el-tag v-for="(item,index) of displayCourse.tch_adjustments" :key="index" style="margin:auto 4px;">{{ item.name }}</el-tag>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row :gutter="20">
                <el-col :span="14">
                  <el-form-item label="Status">
                    <el-tag v-show="displayCourse.status == 4" type="success" >Done Scheduling</el-tag>
                    <el-tag v-show="displayCourse.status == 3" type="warning" >Scheduling</el-tag>
                    <el-tag v-show="displayCourse.status == 2" type="danger" >Stopped Collection</el-tag>
                    <el-tag v-show="displayCourse.status == 1" type="warning" >Collecting Appointments</el-tag>
                    <el-tag v-show="displayCourse.status == 0" type="info" >Waiting to Start</el-tag>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-divider/>
              <el-row :gutter="20">
                <h4 style="margin-top:0px;">Course Introduction</h4>
                <div class="editor-content" v-html="displayCourse.detail"/>
              </el-row>
            </el-form>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-row>
          <box-card :tch_info="displayCourse.tch"/>
        </el-row>
        <el-row style="margin-top:20px;">
          <el-card class="box-card appointment_info" style="min-height:300px;">
            <div slot="header" class="clearfix head-title">
              <div class="head-text">
                Appointments
              </div>
              <div
                class="action-wrapper"
                @click="handleSearchAppointment"
              >
                <svg-icon icon-class="search" class-name="item-icon" />
              </div>
            </div>
            <div v-show="appointments.length == 0" class="card_body-container">
              <div
                style="height:200px;text-align:center;
            text-shadow: 0.5px 0.5px 0.5px #000, -1px -1px 1px #fff;background:rgba(160, 160, 160);filter:alpha(opacity=50);-moz-opacity:0.5;opacity:0.5; ">
                <div style="line-height: 100px;height:100px;">
                  No appointment
                </div>

              </div>
            </div>
            <div style="z-index:99;">
              <pie-chart ref="pie_chart" :chartdata="chartdata"/>
            </div>
          </el-card>
        </el-row>
      </el-col>
    </el-row>
  </div>
</template>
<script>
import OperationButton from './components/OperationButton'
import BoxCard from './components/BoxCard'
import { getCourseList, updateLifeCycle, askforsch } from '@/api/course'
import { getAppointmentByCid } from '@/api/appointment'
import PieChart from './components/PieChart'
export default {
  name: 'DashboardAdmin',
  components: {
    BoxCard,
    OperationButton,
    PieChart
  },
  data() {
    return {
      courses: [],
      displayIndex: 0,
      appointments: [],
      chartdata: []
    }
  },
  computed: {
    displayCourse() {
      let coursedata = {}
      if (this.courses.length !== 0) {
        coursedata = this.courses[this.displayIndex]
      }
      return coursedata
    }
  },
  created() {
    this.loadCoursesData()
  },
  methods: {
    handleFilter() {
      getAppointmentByCid(this.courses[this.displayIndex].id).then(response => {
        this.chartdata = { 'Waiting': 0, 'Approved': 0, 'Closed': 0 }
        this.appointments = response
        response.forEach(element => {
          if (element.status === 0) {
            this.chartdata['Closed'] = this.chartdata['Closed'] + 1
          }
          if (element.status === 1) {
            this.chartdata['Waiting'] = this.chartdata['Waiting'] + 1
          }
          if (element.status === 2) {
            this.chartdata['Approved'] = this.chartdata['Approved'] + 1
          }
        })
      })
    },
    loadCoursesData() {
      getCourseList().then(response => {
        this.courses = response
        getAppointmentByCid(this.courses[this.displayIndex].id).then(response => {
          this.chartdata = { 'Waiting': 0, 'Approved': 0, 'Closed': 0 }
          this.appointments = response
          response.forEach(element => {
            if (element.status === 0) {
              this.chartdata['Closed'] = this.chartdata['Closed'] + 1
            }
            if (element.status === 1) {
              this.chartdata['Waiting'] = this.chartdata['Waiting'] + 1
            }
            if (element.status === 2) {
              this.chartdata['Approved'] = this.chartdata['Approved'] + 1
            }
          })
          this.refreshChild()
        })
      })
    },
    refreshChild() {
      this.$refs['pie_chart'].refresh() // 执行子组件里的doSth函数。
    },
    handleEdit() {
      this.$router.push({
        path: '/course/edit/',
        query: {
          title: 'Edit-Course-' + this.courses[this.displayIndex].id,
          action: 'Edit',
          id: this.courses[this.displayIndex].id
        }
      })
    },
    handleOpertionButtonClick(action) {
      if (action === 'edit') {
        this.handleEdit()
      } else if (action === 'add') {
        this.$router.push({
          path: '/course/edit/',
          query: {
            title: 'Add-Course',
            action: 'Create'
          }
        })
      } else if (action === 'schedule') {
        askforsch(this.displayCourse.id).then(response => {
          if (response.error_code === 0) {
            this.$notify({
              title: 'Success',
              message: 'The Scheduling Process is done!',
              type: 'success'
            })
            this.$router.push({
              path: '/course/schedulers_tch/',
              query: {
                title: 'Course-' + this.courses[this.displayIndex].id,
                course_id: this.courses[this.displayIndex].id
              }
            })
          } else {
            this.$message({
              type: 'warning',
              message: 'Still Scheduling, Please wait a moment!'
            })
            return false
          }
        })
      } else if (action === 'doschedule') {
        let approved_num = 0
        this.appointments.forEach(element => {
          if (element.status === 2) {
            approved_num = approved_num + 1
          }
        })
        if (approved_num > 0) {
          this.handleLifeCycleUpdate(this.courses[this.displayIndex].id, action)
        } else {
          this.$message({
            type: 'warning',
            message: 'No appoinment has benn approved. Please check the Appointments First'
          })
          return false
        }
      } else {
        this.handleLifeCycleUpdate(this.courses[this.displayIndex].id, action)
      }
    },
    handleLifeCycleUpdate(course_id, action) {
      const updateaction = {
        'id': course_id,
        'action': action
      }
      updateLifeCycle(updateaction).then(response => {
        if (response.error_code === 0) {
          this.$message({
            type: 'success',
            message: 'Save Success!'
          })
          const _current_courseid = this.displayIndex
          this.loadCoursesData()
          this.displayIndex = _current_courseid
        } else {
          return false
        }
      })
    },
    handleSearchAppointment() {
      this.$router.push({
        path: '/course/appointments_tch/',
        query: {
          course_id: this.courses[this.displayIndex].id
        }
      })
    }
  }
}
</script>
<style lang="scss" scoped>
.page-container {
  padding: 25px;
  height: 100%;
  background: rgb(240, 242, 245);
}
.box-card /deep/ .el-card__header {
  background: rgb(108, 176, 243);
  color:rgb(255, 255, 255);
  border: 0px;
  border-radius: 0px;
  border-top-right-radius:5px;
  border-top-left-radius:5px;
}
.box-card /deep/ .el-card__body {
  border-radius: 0px;
  border-bottom-right-radius:5px;
  border-bottom-left-radius:5px;
  background-color: transparent;
}
.box-card {
  border: 0px;
  margin: 5px;
  background-color: transparent;
  .head-title {
    margin-top: 0px;
    .head-text {
      display: inline-block;
      vertical-align: middle;
      padding-left: 10px;
    }
    .action-wrapper {
      float: right;
      vertical-align: middle;
      .item-icon {
        font-size: 22px;
        cursor:pointer;
        }
    }
  }

  .card_body-container {
    transition: min-width .5s;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.4);
    padding: 0px;
  }
}
.el-divider{
  margin-top: 0px !important;
}
</style>
