<template>
  <div class="page-container">
    <el-row :gutter="20">
      <el-col :span="3">
        <app-steps/>
      </el-col>
      <el-col :span="21">
        <app-form/>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import AppForm from './components/Form'
import AppSteps from './components/Steps'
export default{
  components: {
    AppForm,
    AppSteps
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.page-container {
  padding: 25px;
  height: 100%;
  background: rgb(240, 242, 245);
}
</style>

