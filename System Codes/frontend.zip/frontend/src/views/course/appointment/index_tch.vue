<template>
  <div class="page-container">
    <div class="filter-container">
      <el-select v-model="searchform.course_id" placeholder="Course ID" style="width: 160px" class="filter-item" @change="handleFilter">
        <el-option v-for="(item,index) in course_ids" :key="index" :label="item" :value="item"/>
      </el-select>
      <el-input v-model="searchform.stu_name" placeholder="Student Name" style="width: 130px;" class="filter-item" @keyup.enter.native="handleFilter"/>
      <el-select v-model="searchform.type" placeholder="Type" style="width: 160px" class="filter-item" @change="handleFilter">
        <el-option v-for="(item,index) in typelist" :key="index" :label="item" :value="item"/>
      </el-select>
      <el-select v-model="searchform.status" placeholder="Status" style="width: 160px" class="filter-item" @change="handleFilter">
        <el-option v-for="(item,index) in statuslist" :key="index" :label="item.label" :value="item.value"/>
      </el-select>
      <el-button v-waves :loading="refreshLoading" class="filter-item" type="primary" icon="el-icon-refresh" circle @click="handleRefresh"/>
      <div v-show="searchform.course_id" style="float:right;">
        <el-tag v-show="target_course.status == 3" type="success" >Course Status: Done Scheduling</el-tag>
        <el-tag v-show="target_course.status == 2" type="success" >Course Status: Started</el-tag>
        <el-tag v-show="target_course.status == 1" type="warning" >Course Status: Waiting</el-tag>
        <el-tag v-show="target_course.status == 0" type="error" >Course Status: Closed{{ target_course.status }}</el-tag>
        <el-tag type="warning">Limited Num: {{ target_course.classes_num_limited }}</el-tag>
        <el-tag v-if="target_course.appointment_types" type="success">Approved Num: {{ target_course.appointment_types.approved_classes_num }}</el-tag>
      </div>
    </div>
    <el-table
      v-loading="listLoading"
      :data="tabledata"
      stripe
      highlight-current-row
      style="width: 100%;margin-top:10px;"
    >
      <el-table-column type="expand">
        <template slot-scope="props">
          <el-form label-position="left" inline class="table-expand">
            <el-row>
              <el-col :span="12">
                <el-form-item label="Need Modules:">
                  <div style="display:inline;">
                    <el-tag >Listening: {{ props.row.recommend_listening }}</el-tag>
                    <el-tag >Reading: {{ props.row.recommend_reading }}</el-tag>
                    <el-tag >Speaking: {{ props.row.recommend_speaking }}</el-tag>
                    <el-tag >Writing: {{ props.row.recommend_writing }}</el-tag>
                  </div>
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="Target Scores:">
                  <div style="display:inline;">
                    <el-tag >Listening: {{ props.row.target_listening }}</el-tag>
                    <el-tag >Reading: {{ props.row.target_reading }}</el-tag>
                    <el-tag >Speaking: {{ props.row.target_speaking }}</el-tag>
                    <el-tag >Writing: {{ props.row.target_writing }}</el-tag>
                    <el-tag >Total: {{ props.row.target_writing }}</el-tag>
                  </div>
                </el-form-item>
              </el-col>
            </el-row>
            <el-form-item label="Peasonal Adjustments">
              <el-tag v-for="(item,index) of props.row.stu_adjustments" :key="index" type="warning">{{ item.name }}</el-tag>
            </el-form-item>
          </el-form>
        </template>
      </el-table-column>
      <el-table-column label="Course ID" prop="course_id" align="center" width="125">
        <template slot-scope="scope">
          <span>{{ scope.row.id }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Student" align="center">
        <template slot-scope="scope">
          <span>{{ scope.row.student.name }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Teacher" align="center">
        <template slot-scope="scope">
          <span>{{ scope.row.teacher.name }}</span>
        </template>
      </el-table-column>
      <el-table-column label="Type" align="center">
        <template slot-scope="scope">
          <el-tag v-show="scope.row.type == 'IELTS'" type="success" >IELTS</el-tag>
          <el-tag v-show="scope.row.type == 'TOEFL'" type="success" >TOEFL</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="Status" align="center">
        <template slot-scope="scope">
          <el-tag v-show="scope.row.status == 2" type="success" >Approved</el-tag>
          <el-tag v-show="scope.row.status == 1" type="warning" >Waiting</el-tag>
          <el-tag v-show="scope.row.status == 0" type="error" >Close</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="Listening(Test)" align="center" width="125">
        <template slot-scope="scope">
          <el-tag >{{ scope.row.point_listening }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="Reading(Test)" align="center" width="125">
        <template slot-scope="scope">
          <el-tag >{{ scope.row.point_reading }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="Speaking(Test)" align="center" width="125">
        <template slot-scope="scope">
          <el-tag >{{ scope.row.point_speaking }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="Writing(Test)" align="center" width="125">
        <template slot-scope="scope">
          <el-tag >{{ scope.row.point_writing }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="Total(Test)" align="center" width="125">
        <template slot-scope="scope">
          <el-tag >{{ scope.row.point_total }}</el-tag>
        </template>
      </el-table-column>

      <el-table-column :resizable="false" label="Action" align="center" fixed="right" width="230">
        <template slot-scope="scope">
          <el-button v-show="scope.row.status == 0 &&(scope.row.course.status !== 2 || scope.row.course.status !== 0)" size="mini" type="primary" @click="handleDetail(scope.$index, scope.row)">Reapprove</el-button>
          <el-button v-show="scope.row.status == 1" size="mini" type="primary" @click="handleDetail(scope.$index, scope.row)">Approve</el-button>
          <el-button v-show="scope.row.status !== 0" size="mini" type="danger" @click="handleDelete(scope.$index, scope.row)">Close</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div style="text-align: center;margin-top: 30px;">
      <el-pagination
        :total="total"
        :page-size="pagesize"
        background
        layout="prev, pager, next"
        @current-change="current_change"
      />
    </div>
  </div>
</template>

<script>
import { getAppointmentInfoList, updateAppointmentStatus } from '@/api/appointment'
import waves from '@/directive/waves' // Waves directive
export default {
  name: 'Projectinfo',
  directives: { waves },
  data() {
    return {
      list: [],
      listLoading: true,
      refreshLoading: false,
      dialogVisible: false,
      confirmLoading: false,
      pickerOptions: {
        shortcuts: [{
          text: 'Today',
          onClick(picker) {
            picker.$emit('pick', new Date())
          }
        }, {
          text: 'Yesterday',
          onClick(picker) {
            const date = new Date()
            date.setTime(date.getTime() - 3600 * 1000 * 24)
            picker.$emit('pick', date)
          }
        }, {
          text: 'A week ago',
          onClick(picker) {
            const date = new Date()
            date.setTime(date.getTime() - 3600 * 1000 * 24 * 7)
            picker.$emit('pick', date)
          }
        }]
      },
      target_course: {},
      search: '',
      typelist: ['IELTS', 'TOEFL'],
      statuslist: [
        {
          value: 1,
          label: 'Waiting for approval'
        },
        {
          value: 0,
          label: 'Close'
        },
        {
          value: 2,
          label: 'Approved'
        }
      ],
      searchform: {
        type: '',
        course_id: '',
        status: ''
      },
      rules: {
      },
      total: 0,
      pagesize: 10,
      currentPage: 1,
      createdataoptions: [
      ],
      switch_onlyactived: false
    }
  },
  computed: {
    lifecycle() {
      return this.$store.getters.lifecycle
    },
    tabledata() {
      return this.list.slice(
        (this.currentPage - 1) * this.pagesize,
        this.currentPage * this.pagesize
      )
    },
  },
  watch: {
  },
  created() {
    if (this.$route.query.course_id) {
      this.searchform.course_id = this.$route.query.course_id
    }
    this.getList()
  },
  methods: {
    current_change: function(currentPage) {
      this.currentPage = currentPage
    },
    getList() {
      console.log(this.searchform)
      this.listLoading = true
      this.refreshLoading = true
      getAppointmentInfoList(this.searchform).then(response => {
        this.list = response.appointments
        this.course_ids = response.course_ids
        if (this.searchform.course_id && this.searchform.course_id !== 0) {
          this.target_course = response.target_course
        }
        this.listLoading = false
        this.refreshLoading = false
      })
    },
    handleFilter() {
      this.getList()
    },
    handleRefresh() {
      this.searchform.course_id = ''
      this.searchform.type = ''
      this.searchform.status = ''
      this.getList()
    },
    handleDetail(index, row) {
      this.$confirm('Approve this appointment ?', 'Message', {
        confirmButtonText: 'Confirm',
        cancelButtonText: 'Cancel',
        type: 'warning'
      }).then(() => {
        updateAppointmentStatus(row.id, '2').then(response => {
          if (response.error_code === 0) {
            this.$notify({
              title: 'Success',
              message: 'Success',
              type: 'success',
              offset: 100
            })
            this.getList()
          } else {
            this.$notify({
              title: 'Error',
              message: 'Error',
              type: 'error',
              offset: 100
            })
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: 'Cancel Action'
        })
      })
    },
    handleDelete(index, row) {
      this.$confirm('Close this appointment ?', 'Message', {
        confirmButtonText: 'Confirm',
        cancelButtonText: 'Cancel',
        type: 'warning'
      }).then(() => {
        updateAppointmentStatus(row.id, '0').then(response => {
          if (response.error_code === 0) {
            this.$notify({
              title: 'Success',
              message: 'Success',
              type: 'success',
              offset: 100
            })
            this.getList()
          } else {
            this.$notify({
              title: 'Error',
              message: 'Error',
              type: 'error',
              offset: 100
            })
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: 'Cancel Action'
        })
      })
    }

  }
}
</script>
<style rel="stylesheet/scss" lang="scss" scoped>
.page-container {
  padding: 25px;
  background-color: rgb(240, 242, 245);
}
.table-expand {
    font-size: 0;
  }
  .table-expand label {
    width: 90px;
    color: #99a9bf;
  }
  .table-expand .el-form-item {
    margin-right: 0;
    margin-bottom: 0;
    width: 100%;
    .el-tag{
      margin-right:5px;
    }
  }
</style>
