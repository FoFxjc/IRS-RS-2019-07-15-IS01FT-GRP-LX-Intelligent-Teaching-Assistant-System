<template>
  <div class="steps-container">
    <el-steps :active="active" align-center class="steps-wrapper" direction="vertical" finish-status="success">
      <el-step v-for="(item,index) of stepsList" :key="index" :title="item.title" />
    </el-steps>
  </div>

</template>
<script>
import bus from '@/assets/eventBus'
export default {
  data() {
    return {
      stepsList: [
        {
          title: 'Basic Info'
        },
        {
          title: 'Modules Info'
        },
        {
          title: 'Personal Adjustment'
        },
        {
          title: 'Confirm'
        }
      ],
      active: 0
    }
  },
  mounted() {
    this.sendStepStatus()
    const thiscp = this
    bus.$on('nextAddRepoStep', function(msg) {
      thiscp.active++
      thiscp.sendStepStatus()
    })
    bus.$on('preAddRepoStep', function(msg) {
      if (thiscp.active - 1 <= 0) {
        thiscp.active = 0
      } else {
        thiscp.active--
      }
      thiscp.sendStepStatus()
    })
  },
  methods: {
    sendStepStatus() {
      bus.$emit('sendAddRepoStepStatus', { 'length': this.stepsList.length, 'status': this.active })
    }
  }
}
</script>
<style lang="stylus" scoped>
.steps-container
  height 700px
  display flex
  flex-direction column
  justify-content center
  align-items center
  .steps-wrapper
    margin-top 5px
    height 90%

</style>

