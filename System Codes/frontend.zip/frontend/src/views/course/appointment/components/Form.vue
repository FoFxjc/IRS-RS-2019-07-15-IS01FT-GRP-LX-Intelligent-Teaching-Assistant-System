<template>
  <div class="form-container">
    <el-card class="box-card form-wrapper">
      <el-form ref="basic_form" :model="form" :rules="rules" label-position="right" label-width="180px" style="margin: 30px 0;">
        <div v-show="stepsstatus == 0" ref="step1" class="step">
          <h1 class="step-title">Basic Info</h1>
          <el-divider />
          <div style="margin-top:10px;">
            <el-row>
              <el-col :span="10">
                <el-form-item label="Course ID" prop="id">
                  <el-input :rows="1" v-model="form.course_id" class="article-input" placeholder="Course ID" readonly/>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="10">
                <el-form-item label="Selected Type" prop="selected_type">
                  <el-radio-group v-model="form.selected_type">
                    <el-radio-button v-for="(item,index) of coursedata.types" :key="index" :label="item">{{ item }}</el-radio-button>
                  </el-radio-group>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="10">
                <el-form-item label="Teacher ID" prop="tch_id">
                  <el-input :rows="1" v-model="form.tch_id" class="article-input" placeholder="Teacher ID" readonly/>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-form-item label="Course Range">
                <div style="text-aligh:center;padding-left:15px;font-size:16px;">
                  <span>{{ coursedata.start_date }}</span>
                  <i class="el-icon-minus" />
                  <span>{{ coursedata.end_date }}</span>
                </div>
              </el-form-item>
            </el-row>
          </div>
        </div>
        <div v-show="stepsstatus == 1" ref="step2" class="step">
          <h1 class="step-title">Modules Info -- {{ form.selected_type }}</h1>
          <el-divider content-position="left">Please enter your total score and each module's score for the entrance test</el-divider>
          <el-form ref="module_form" :inline="true" :model="module_form" :rules="module_rules" label-position="right" label-width="80px" style="margin: 30px 0;">
            <el-row>
              <el-form-item v-show="form.selected_type == 'IELTS'" label="Listening" prop="i_point_listening">
                <el-input-number v-model="module_form.ielts.point_listening" :step="0.5" :min="0" :max="9" size="small" controls-position="right"/>
              </el-form-item>
              <el-form-item v-show="form.selected_type == 'IELTS'" label="Reading" prop="i_point_reading">
                <el-input-number v-model="module_form.ielts.point_reading" :step="0.5" :min="0" :max="9" size="small" controls-position="right"/>
              </el-form-item>
              <el-form-item v-show="form.selected_type == 'IELTS'" label="Speaking" prop="i_point_speaking">
                <el-input-number v-model="module_form.ielts.point_speaking" :step="0.5" :min="0" :max="9" size="small" controls-position="right"/>
              </el-form-item>
              <el-form-item v-show="form.selected_type == 'IELTS'" label="Writing" prop="i_point_writing">
                <el-input-number v-model="module_form.ielts.point_writing" :step="0.5" :min="0" :max="9" size="small" controls-position="right"/>
              </el-form-item>
              <el-form-item v-show="form.selected_type == 'IELTS'" label="Total" prop="i_point_total">
                <el-input-number :value="ielts_p_total" :step="0.5" :min="0" :max="9" size="small" controls-position="right" disabled/>
              </el-form-item>
              <el-form-item v-show="form.selected_type == 'TOEFL'" label="Listening" prop="t_point_listening">
                <el-input-number v-model="module_form.toefl.point_listening" :step="1" :min="0" :max="30" size="small" controls-position="right"/>
              </el-form-item>
              <el-form-item v-show="form.selected_type == 'TOEFL'" label="Reading" prop="t_point_reading">
                <el-input-number v-model="module_form.toefl.point_reading" :step="1" :min="0" :max="30" size="small" controls-position="right"/>
              </el-form-item>
              <el-form-item v-show="form.selected_type == 'TOEFL'" label="Speaking" prop="t_point_speaking">
                <el-input-number v-model="module_form.toefl.point_speaking" :step="1" :min="0" :max="30" size="small" controls-position="right"/>
              </el-form-item>
              <el-form-item v-show="form.selected_type == 'TOEFL'" label="Writing" prop="t_point_writing">
                <el-input-number v-model="module_form.toefl.point_writing" :step="1" :min="0" :max="30" size="small" controls-position="right"/>
              </el-form-item>
              <el-form-item v-show="form.selected_type == 'TOEFL'" label="Total" prop="t_point_total">
                <el-input-number :value="toefl_p_total" :step="1" :min="0" :max="120" size="small" controls-position="right" disabled/>
              </el-form-item>
            </el-row>
            <el-divider content-position="left">Please enter your target score</el-divider>
            <el-row>
              <el-form-item v-show="form.selected_type == 'IELTS'" label="Listening" prop="i_point_listening">
                <el-input-number v-model="module_form.ielts.target_listening" :step="0.5" :min="0" :max="9" size="small" controls-position="right"/>
              </el-form-item>
              <el-form-item v-show="form.selected_type == 'IELTS'" label="Reading" prop="i_point_reading">
                <el-input-number v-model="module_form.ielts.target_reading" :step="0.5" :min="0" :max="9" size="small" controls-position="right"/>
              </el-form-item>
              <el-form-item v-show="form.selected_type == 'IELTS'" label="Speaking" prop="i_point_speaking">
                <el-input-number v-model="module_form.ielts.target_speaking" :step="0.5" :min="0" :max="9" size="small" controls-position="right"/>
              </el-form-item>
              <el-form-item v-show="form.selected_type == 'IELTS'" label="Writing" prop="i_point_writing">
                <el-input-number v-model="module_form.ielts.target_writing" :step="0.5" :min="0" :max="9" size="small" controls-position="right"/>
              </el-form-item>
              <el-form-item v-show="form.selected_type == 'IELTS'" label="Total" prop="i_point_total">
                <el-input-number :value="ielts_t_total" :step="0.5" :min="0" :max="9" size="small" controls-position="right" disabled/>
              </el-form-item>
              <el-form-item v-show="form.selected_type == 'TOEFL'" label="Listening" prop="t_point_listening">
                <el-input-number v-model="module_form.toefl.target_listening" :step="1" :min="0" :max="30" size="small" controls-position="right"/>
              </el-form-item>
              <el-form-item v-show="form.selected_type == 'TOEFL'" label="Reading" prop="t_point_reading">
                <el-input-number v-model="module_form.toefl.target_reading" :step="1" :min="0" :max="30" size="small" controls-position="right"/>
              </el-form-item>
              <el-form-item v-show="form.selected_type == 'TOEFL'" label="Speaking" prop="t_point_speaking">
                <el-input-number v-model="module_form.toefl.target_speaking" :step="1" :min="0" :max="30" size="small" controls-position="right"/>
              </el-form-item>
              <el-form-item v-show="form.selected_type == 'TOEFL'" label="Writing" prop="t_point_writing">
                <el-input-number v-model="module_form.toefl.target_writing" :step="1" :min="0" :max="30" size="small" controls-position="right"/>
              </el-form-item>
              <el-form-item v-show="form.selected_type == 'TOEFL'" label="Total" prop="t_point_total">
                <el-input-number :value="toefl_t_total" :step="1" :min="0" :max="120" size="small" controls-position="right" disabled/>
              </el-form-item>
              <el-button :loading="uploading" :disabled="coursedata.status == 4" type="primary" @click="uploadTestPoints">Upload</el-button>
            </el-row>
            <el-divider content-position="center" style="margin-top:15px;">lecture number of each module (recommend) </el-divider>
            <el-form-item label="Listening" prop="listening">
              <el-input-number v-model="module_form.modules.listening" :disabled="true"/>
            </el-form-item>
            <el-form-item label="Reading" prop="reading">
              <el-input-number v-model="module_form.modules.reading" :disabled="true"/>
            </el-form-item>
            <el-form-item label="Speaking" prop="speaking">
              <el-input-number v-model="module_form.modules.speaking" :disabled="true"/>
            </el-form-item>
            <el-form-item label="Writing" prop="writing">
              <el-input-number v-model="module_form.modules.writing" :disabled="true"/>
            </el-form-item>
          </el-form>
        </div>
        <div v-show="stepsstatus == 2" ref="step3" class="step">
          <h1 class="step-title">Personal Adjustments</h1>
          <el-divider content-position="left"/>
          <el-form-item prop="cimonitor">
            <el-form-item prop="personal_adjustments">
              <el-transfer
                v-model="form.personal_adjustments"
                :data="loaddata.adjustments"
                :titles="['Available', 'Selected']"
                :format="{
                  noChecked: '${total}',
                  hasChecked: '${checked}/${total}'
                }"
              />
            </el-form-item>
          </el-form-item>
        </div>
        <div v-show="stepsstatus == 3" ref="step3" class="comfirm-step">
          <h1 class="step-title">Confirm info</h1>
          <el-divider content-position="left"/>
          <div style="margin-top:20px;">
            <el-row :gutter="28">
              <el-col :span="10">
                <el-form label-position="right" label-width="135px">
                  <el-row>
                    <el-col :span="18">
                      <el-form-item label="Student ID">
                        <el-input :value="form.stu_id" :rows="1" class="article-input" placeholder="Empty" readonly/>
                      </el-form-item>
                    </el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="18">
                      <el-form-item label="Student Name">
                        <el-input :rows="1" :value="form.stu_name" class="article-input" placeholder="Empty" readonly/>
                      </el-form-item>
                    </el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="18">
                      <el-form-item label="Course Name">
                        <el-input :rows="1" :value="form.course_name" class="article-input" placeholder="Empty" readonly/>
                      </el-form-item>
                    </el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="18">
                      <el-form-item label="Course Type">
                        <el-input :rows="1" :value="form.selected_type" class="article-input" placeholder="Empty" readonly/>
                      </el-form-item>
                    </el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="18">
                      <el-form-item label="Course Range">
                        <div style="text-aligh:center;padding-left:15px;font-size:16px;">
                          <span>{{ coursedata.start_date }}</span>
                          <i class="el-icon-minus" />
                          <span>{{ coursedata.end_date }}</span>
                        </div>
                      </el-form-item>
                    </el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="18">
                      <el-form-item label="Teacher Name">
                        <el-input :rows="1" :value="form.tch_name" class="article-input" placeholder="Empty" readonly/>
                      </el-form-item>
                    </el-col>
                  </el-row>
                </el-form>
              </el-col>
              <el-col :span="14">
                <el-form :inline="true" label-position="right">
                  <el-divider content-position="left" class="narrow_divider">In Entrance Test</el-divider>
                  <el-form-item label="Listening:" label-width="80px">
                    <el-tag style="margin:auto 2px;">{{ module_form[form.selected_type.toLowerCase()].point_listening }}</el-tag>
                  </el-form-item>
                  <el-form-item label="Reading:" label-width="80px">
                    <el-tag style="margin:auto 2px;">{{ module_form[form.selected_type.toLowerCase()].point_reading }}</el-tag>
                  </el-form-item>
                  <el-form-item label="Speaking:" label-width="80px">
                    <el-tag style="margin:auto 2px;">{{ module_form[form.selected_type.toLowerCase()].point_speaking }}</el-tag>
                  </el-form-item>
                  <el-form-item label="Writing:" label-width="80px">
                    <el-tag style="margin:auto 2px;">{{ module_form[form.selected_type.toLowerCase()].point_writing }}</el-tag>
                  </el-form-item>
                  <el-form-item label="Total:" label-width="80px">
                    <el-tag v-show="form.selected_type.toLowerCase() == 'ielts'" style="margin:auto 2px;">{{ ielts_p_total }}</el-tag>
                    <el-tag v-show="form.selected_type.toLowerCase() == 'toefl'" style="margin:auto 2px;">{{ toefl_p_total }}</el-tag>
                  </el-form-item>
                  <el-divider content-position="left" class="narrow_divider">Target</el-divider>
                  <el-form-item label="Listening:" label-width="80px">
                    <el-tag style="margin:auto 2px;">{{ module_form[form.selected_type.toLowerCase()].target_listening }}</el-tag>
                  </el-form-item>
                  <el-form-item label="Reading:" label-width="80px">
                    <el-tag style="margin:auto 2px;">{{ module_form[form.selected_type.toLowerCase()].target_reading }}</el-tag>
                  </el-form-item>
                  <el-form-item label="Speaking:" label-width="80px">
                    <el-tag style="margin:auto 2px;">{{ module_form[form.selected_type.toLowerCase()].target_speaking }}</el-tag>
                  </el-form-item>
                  <el-form-item label="Writing:" label-width="80px">
                    <el-tag style="margin:auto 2px;">{{ module_form[form.selected_type.toLowerCase()].target_writing }}</el-tag>
                  </el-form-item>
                  <el-form-item label="Total:" label-width="80px">
                    <el-tag v-show="form.selected_type.toLowerCase() == 'ielts'" style="margin:auto 2px;">{{ ielts_t_total }}</el-tag>
                    <el-tag v-show="form.selected_type.toLowerCase() == 'toefl'" style="margin:auto 2px;">{{ toefl_t_total }}</el-tag>
                  </el-form-item>
                  <el-divider content-position="left" class="narrow_divider">In Course</el-divider>
                  <el-form-item label="Listening:" label-width="80px">
                    <el-tag style="margin:auto 2px;">{{ module_form.modules.listening }}</el-tag>
                  </el-form-item>
                  <el-form-item label="Reading:" label-width="80px">
                    <el-tag style="margin:auto 2px;">{{ module_form.modules.reading }}</el-tag>
                  </el-form-item>
                  <el-form-item label="Speaking:" label-width="80px">
                    <el-tag style="margin:auto 2px;">{{ module_form.modules.speaking }}</el-tag>
                  </el-form-item>
                  <el-form-item label="Writing:" label-width="80px">
                    <el-tag style="margin:auto 2px;">{{ module_form.modules.writing }}</el-tag>
                  </el-form-item>
                  <el-divider content-position="left" class="narrow_divider">Personal Adjustments</el-divider>
                  <el-row>
                    <el-tag v-for="(item,index) of showAdjustment" :key="index" style="margin:auto 4px;">{{ item }}</el-tag>
                  </el-row>
                </el-form>
              </el-col>
            </el-row>
          </div>
        </div>
      </el-form>
      <div class="bottom clearfix">
        <el-button v-show="haspreStep" icon="el-icon-arrow-left" style="float:left;margin: 5px;" @click="preStep()">preStep</el-button>
        <el-button v-show="hasnextStep" style="float:right;margin: 5px;" @click="nextStep()">
          nextStep
          <i class="el-icon-arrow-right el-icon--right"/>
        </el-button>
        <el-button v-show="!hasnextStep" style="float:right;margin: 5px;" @click="closeCurrentView()">Cancel</el-button>
        <el-button v-show="!hasnextStep && !form.id" :disabled="coursedata.status === 4 || coursedata.status === 3" type="primary" style="float:right;margin: 5px;" @click="handleSubmit()">Submit</el-button>
        <el-button v-show="!hasnextStep && form.id" :disabled="coursedata.status === 4 || coursedata.status === 3" type="primary" style="float:right;margin: 5px;" @click="handleSubmit()">Save</el-button>
      </div>

    </el-card>
  </div>
</template>
<script>
import MDinput from '@/components/MDinput'
import bus from '@/assets/eventBus'
import Tinymce from '@/components/Tinymce'
import { updateTestPoints, updateAppointment, getAppointmentInfo } from '@/api/appointment'
import { getCourseList } from '@/api/course'
import { getAdjustments } from '@/api/adjustment'
export default {
  components: {
    MDinput,
    Tinymce
  },
  data() {
    return {
      stepslength: 100,
      stepsstatus: 0,
      global_disabled: false,
      beacon_disabled: true,
      uploading: false,
      form: {
        course_id: '',
        stu_id: this.$store.getters.id,
        stu_name: this.$store.getters.name,
        selected_type: 'IELTS',
        tch_id: '',
        personal_adjustments: []
      },
      loaddata: {
        adjustments: []
      },
      module_form: {
        ielts: {
          point_listening: 4.5,
          point_reading: 4.5,
          point_writing: 4.5,
          point_speaking: 4.5,
          point_total: 4.5,
          target_listening: 6,
          target_reading: 6,
          target_writing: 6,
          target_speaking: 6,
          target_total: 6
        },
        toefl: {
          point_listening: 15,
          point_reading: 15,
          point_writing: 15,
          point_speaking: 15,
          point_total: 60,
          target_listening: 25,
          target_reading: 25,
          target_writing: 25,
          target_speaking: 25
        },
        modules: {
          listening: 0,
          reading: 0,
          writing: 0,
          speaking: 0
        }
      },
      predata: {},
      rules: {
        course_id: [
          { required: true, trigger: 'blur' }
        ],
        stu_id: [
          { required: true, trigger: 'blur' }
        ],
        selected_type: [
          { required: true, message: 'Pleace choose Stream Type', trigger: 'change' }
        ],
        tch_id: [
          { required: true, trigger: 'blur' }
        ]
      },
      validlist: [
        ['course_id', 'stu_id', 'selected_type', 'tch_id'],
        ['listening', 'reading', 'writing', 'speaking'],
        []
      ]
    }
  },
  computed: {
    toefl_p_total: function() {
      return this.module_form.toefl.point_listening +
             this.module_form.toefl.point_reading +
             this.module_form.toefl.point_writing +
             this.module_form.toefl.point_speaking
    },
    ielts_p_total: function() {
      const average = (this.module_form.ielts.point_listening +
             this.module_form.ielts.point_reading +
             this.module_form.ielts.point_writing +
             this.module_form.ielts.point_speaking) / 4
      const int_average = parseInt(average)
      if ((average - int_average) < 0.25) {
        return int_average
      } else {
        if ((average - int_average) >= 0.25 && (average - int_average) <= 0.75) {
          return int_average + 0.5
        } else {
          return int_average + 1
        }
      }
    },
    toefl_t_total: function() {
      return this.module_form.toefl.target_listening +
             this.module_form.toefl.target_reading +
             this.module_form.toefl.target_writing +
             this.module_form.toefl.target_speaking
    },
    ielts_t_total: function() {
      const average = (this.module_form.ielts.target_listening +
             this.module_form.ielts.target_reading +
             this.module_form.ielts.target_writing +
             this.module_form.ielts.target_speaking) / 4
      const int_average = parseInt(average)
      if ((average - int_average) < 0.25) {
        return int_average
      } else {
        if ((average - int_average) >= 0.25 && (average - int_average) <= 0.75) {
          return int_average + 0.5
        } else {
          return int_average + 1
        }
      }
    },
    showAdjustment: function() {
      const displayData = []
      this.form.personal_adjustments.forEach((item, index) => {
        this.loaddata.adjustments.forEach((o_item, o_index) => {
          if (item === o_item.key) {
            displayData.push(o_item.label)
          }
        })
      })
      return displayData
    },
    hasnextStep: function() {
      if (this.stepsstatus < this.stepslength - 1 && this.stepsstatus >= 0) {
        return true
      }
      if (this.stepsstatus === this.stepslength - 1) {
        return false
      }
    },
    haspreStep: function() {
      if (this.stepsstatus <= this.stepslength - 1 && this.stepsstatus > 0) {
        return true
      }
      if (this.stepsstatus === 0) {
        return false
      }
    },
    showRelease: function() {
      return this.release_prepend + this.form.release
    }
  },
  mounted() {
    const thiscp = this
    bus.$on('sendAddRepoStepStatus', function(stepstatus) {
      thiscp.stepslength = stepstatus.length
      thiscp.stepsstatus = stepstatus.status
    })
  },
  created() {
    this.loadPersonalAdjustment()
    if (this.$route.query.action === 'create') {
      const course_id = this.$route.query.course_id
      this.loadCourseInfo(course_id)
    }
    if (this.$route.query.action === 'edit') {
      const appointment_id = this.$route.query.appointment_id
      this.loadAppointmentInfo(appointment_id)
    }
    this.tempRoute = Object.assign({}, this.$route)
  },
  methods: {
    loadAppointmentInfo(appointment_id) {
      getAppointmentInfo(appointment_id).then(response => {
        this.coursedata = response.course
        if (this.coursedata.status === 4 || this.coursedata.status === 3) {
          this.$message('The target course of this appoinment is in the scheduling process, You can not change anything.')
        }
        this.form.id = response.id
        this.form.course_id = this.coursedata.id
        this.form.tch_id = this.coursedata.tch.id
        this.form.course_name = this.coursedata.name
        this.form.tch_name = this.coursedata.tch.name
        this.form.selected_type = response.type
        this.form.personal_adjustments = response.stu_adjustments
        this.module_form[this.form.selected_type.toLowerCase()].point_listening = response.point_listening
        this.module_form[this.form.selected_type.toLowerCase()].point_reading = response.point_reading
        this.module_form[this.form.selected_type.toLowerCase()].point_writing = response.point_writing
        this.module_form[this.form.selected_type.toLowerCase()].point_speaking = response.point_speaking
        this.module_form[this.form.selected_type.toLowerCase()].target_listening = response.target_listening
        this.module_form[this.form.selected_type.toLowerCase()].target_reading = response.target_reading
        this.module_form[this.form.selected_type.toLowerCase()].target_writing = response.target_writing
        this.module_form[this.form.selected_type.toLowerCase()].target_speaking = response.target_speaking

        this.module_form.modules.listening = response.recommend_listening
        this.module_form.modules.reading = response.recommend_reading
        this.module_form.modules.writing = response.recommend_writing
        this.module_form.modules.speaking = response.recommend_speaking
      })
    },
    loadPersonalAdjustment() {
      getAdjustments().then(response => {
        const ad_data = []
        response.forEach((item, index) => {
          ad_data.push({
            key: item.id,
            label: item.name
          })
        })
        this.loaddata.adjustments = ad_data
      })
    },
    uploadTestPoints() {
      const uploaddata = {}
      uploaddata.type = this.form.selected_type
      uploaddata.point_listening = this.module_form[this.form.selected_type.toLowerCase()].point_listening
      uploaddata.point_reading = this.module_form[this.form.selected_type.toLowerCase()].point_reading
      uploaddata.point_writing = this.module_form[this.form.selected_type.toLowerCase()].point_writing
      uploaddata.point_speaking = this.module_form[this.form.selected_type.toLowerCase()].point_speaking
      uploaddata.target_listening = this.module_form[this.form.selected_type.toLowerCase()].target_listening
      uploaddata.target_reading = this.module_form[this.form.selected_type.toLowerCase()].target_reading
      uploaddata.target_writing = this.module_form[this.form.selected_type.toLowerCase()].target_writing
      uploaddata.target_speaking = this.module_form[this.form.selected_type.toLowerCase()].target_speaking
      this.uploading = true
      updateTestPoints(uploaddata).then(response => {
        this.module_form.modules.listening = response.listening
        this.module_form.modules.reading = response.reading
        this.module_form.modules.writing = response.writing
        this.module_form.modules.speaking = response.speaking
        this.uploading = false
      })
    },
    loadCourseInfo(course_id) {
      getCourseList(course_id).then(response => {
        this.coursedata = response[0]
        this.form.course_id = this.coursedata.id
        this.form.tch_id = this.coursedata.tch.id
        this.form.course_name = this.coursedata.name
        this.form.tch_name = this.coursedata.tch.name
      })
    },
    onSubmit() {
      this.$message('submit!')
    },
    onCancel() {
      this.$message({
        message: 'cancel!',
        type: 'warning'
      })
    },
    updateInfo() {
      this.$refs.form.validate((valid) => {
        if (valid) {
          this.$confirm('Save', 'Confirm', {
            confirmButtonText: 'Save',
            cancelButtonText: 'Cancel',
            type: 'warning'
          })
            .then(() => {
              const updateinfo = Object.assign({}, this.form)
              updateinfo.release = this.showRelease
            })
            .catch(() => {
              this.$message({
                type: 'info',
                message: 'Cancel Submission'
              })
            })
        }
      })
    },
    handleSaveAsDraft() {
      this.$refs.form.validate((valid) => {
        if (valid) {
          this.$confirm('Save as Draft', 'Confirm', {
            confirmButtonText: 'Save',
            cancelButtonText: 'Cancel',
            type: 'warning'
          })
            .then(() => {
              const updateinfo = Object.assign({}, this.form)
              updateinfo.release = this.showRelease
            })
            .catch(() => {
              this.$message({
                type: 'info',
                message: 'Cancel Submission'
              })
            })
        }
      })
    },
    handleSubmit() {
      this.$confirm('Are confirm to submit this appointment?', 'Confirm', {
        confirmButtonText: 'Confirm',
        cancelButtonText: 'Cancel',
        type: 'warning'
      })
        .then(() => {
          const updateinfo = {}
          if ('id' in this.form) {
            updateinfo.id = this.form.id
          }
          updateinfo.course_id = this.form.course_id
          updateinfo.course_type = this.form.selected_type
          updateinfo.point_listening = this.module_form[this.form.selected_type.toLowerCase()].point_listening
          updateinfo.point_speaking = this.module_form[this.form.selected_type.toLowerCase()].point_speaking
          updateinfo.point_reading = this.module_form[this.form.selected_type.toLowerCase()].point_reading
          updateinfo.point_writing = this.module_form[this.form.selected_type.toLowerCase()].point_writing
          if (this.form.selected_type.toLowerCase() === 'ielts') {
            updateinfo.point_total = this.ielts_p_total
            updateinfo.target_total = this.ielts_t_total
          }
          if (this.form.selected_type.toLowerCase() === 'toefl') {
            updateinfo.point_total = this.toefl_p_total
            updateinfo.target_total = this.toefl_t_total
          }
          updateinfo.target_listening = this.module_form[this.form.selected_type.toLowerCase()].target_listening
          updateinfo.target_speaking = this.module_form[this.form.selected_type.toLowerCase()].target_speaking
          updateinfo.target_reading = this.module_form[this.form.selected_type.toLowerCase()].target_reading
          updateinfo.target_writing = this.module_form[this.form.selected_type.toLowerCase()].target_writing
          updateinfo.recommend_speaking = this.module_form.modules.speaking
          updateinfo.recommend_reading = this.module_form.modules.reading
          updateinfo.recommend_writing = this.module_form.modules.writing
          updateinfo.recommend_listening = this.module_form.modules.listening
          updateinfo.stu_adjustments = this.form.personal_adjustments
          updateAppointment(updateinfo).then(response => {
            if (response.error_code === 0) {
              this.$message({
                type: 'success',
                message: 'Save Success!'
              })
              this.closeCurrentView()
            } else {
              return false
            }
          })
            .catch(err => {
              console.log(err)
            })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: 'Cancel Submission'
          })
        })
    },
    isActive(route) {
      return route.path === this.$route.path
    },
    closeCurrentView() {
      const view = this.$route
      this.$store.dispatch('delView', view).then(({ visitedViews }) => {
        if (this.isActive(view)) {
          const latestView = visitedViews.slice(-1)[0]
          if (latestView) {
            this.$router.push(latestView)
          } else {
            this.$router.push('/')
          }
        }
      })
    },
    validate_props(props, formname) {
      let vaildpass = true
      props.forEach((prop, index) => {
        this.$refs[formname].validateField(prop, (valid) => {
          if (valid) {
            vaildpass = false
          }
        })
      })
      return vaildpass
    },
    nextStep() {
      let ispass = true
      if (this.stepsstatus < this.stepslength) {
        if (this.stepsstatus === 0) {
          ispass = this.validate_props(this.validlist[this.stepsstatus], 'basic_form')
        }
        if (this.stepsstatus === 1) {
          if (this.module_form.modules.listening === 0 &&
              this.module_form.modules.reading === 0 &&
              this.module_form.modules.writing === 0 &&
              this.module_form.modules.speaking === 0) {
            ispass = false
          }
        }

        if (ispass) {
          bus.$emit('nextAddRepoStep', 'next')
        } else {
          this.$message({
            message: 'Please complete the form.',
            type: 'error'
          })
        }
      }
    },
    preStep() {
      bus.$emit('preAddRepoStep', 'pre')
    }
  }
}
</script>
<style rel="stylesheet/scss" lang="scss">
.form-container {
  min-height: 500px;
  .form-wrapper {
    position: relative;
    margin-top: 14px;
    min-height: 500px;
    .bottom {
      border-top: 2px solid hsla(0, 0%, 90%, 0.5);
      position: absolute;
      width: 100%;
      bottom: 0;
      left: 0;
      line-height: 20px;
    }
    .step-title {
      line-height: 10px;
      padding-bottom: 5px;
    }
  }
}
.el-divider{
  margin-top: 0px !important;
}
.el-transfer {
  width: 1000px !important;
}
.el-transfer-panel {
  width: 300px !important;
}
.clearfix:before,
.clearfix:after {
  display: table;
  content: '';
}
.clearfix:after {
  clear: both;
}
</style>

