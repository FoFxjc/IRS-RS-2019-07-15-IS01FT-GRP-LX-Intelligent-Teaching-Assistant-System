<template>
  <div>
    <el-steps align-center style="z-index:-100;">
      <el-step v-for="(item,index) of stepsList" :key="index" :title="item.title" :status="item.status">
        <template slot="icon">
          <svg-icon :icon-class="item.icon"/>
        </template>
      </el-step>
    </el-steps>
  </div>
</template>
<script>
export default {
  data() {
    return {
    }
  }
}
</script>
<style rel="stylesheet/scss" lang="scss" scoped>
</style>
