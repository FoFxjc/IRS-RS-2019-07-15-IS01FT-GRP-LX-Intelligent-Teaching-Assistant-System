<template>
  <div>
    <el-steps align-center style="z-index:-100;">
      <el-step v-for="(item,index) of stepsList" :key="index" :title="item.title" :status="item.status">
        <template slot="icon">
          <svg-icon :icon-class="item.icon"/>
        </template>
      </el-step>
    </el-steps>
  </div>
</template>
<script>
export default {
  data() {
    return {
      stepsList: [
        {
          title: 'Create',
          icon: 'create',
          status: 'success'
        },
        {
          title: 'Submit',
          icon: 'submit',
          status: 'success'
        },
        {
          title: 'Assign',
          icon: 'assign',
          status: 'success'
        },
        {
          title: 'Progress',
          icon: 'progress',
          status: 'success'
        },
        {
          title: 'Resolve',
          icon: 'resolve',
          status: 'success'
        },
        {
          title: 'Close',
          icon: 'close'
        },
        {
          title: 'Reject',
          icon: 'reject',
          status: 'error'
        }
      ]
    }
  }
}
</script>
<style rel="stylesheet/scss" lang="scss" scoped>
</style>
