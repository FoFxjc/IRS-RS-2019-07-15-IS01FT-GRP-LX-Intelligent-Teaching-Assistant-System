<template>
  <div class="login-wrapper">
    <div class="login-container">
      <el-form
        ref="loginForm"
        :model="loginForm"
        :rules="loginRules"
        class="login-form"
        auto-complete="on"
        label-position="left"
      >
        <div class="title-container">
          <div class="logo-con">
            <img
              key="min-logo"
              :src="minLogo"
            >
          </div>
          <div>
            <span class="title">Intelligent Teaching Assistant System</span>
          </div>
        </div>
        <el-form-item prop="username">
          <el-input
            v-model="loginForm.username"
            :error="errors.username_error"
            type="text"
            auto-complete="on"
          >
            <el-select slot="prepend" v-model="loginForm.domain">
              <el-option label="Student" value="stu"/>
              <el-option label="Teacher" value="tch"/>
            </el-select>
            <el-button slot="append">
              <svg-icon icon-class="user" />
            </el-button>
          </el-input>
        </el-form-item>
        <el-form-item prop="password">
          <el-input
            :type="pwdType"
            :error="errors.password_error"
            v-model="loginForm.password"
            name="password"
            auto-complete="on"
            @keyup.enter.native="handleLogin">
            <el-button slot="prepend">
              <svg-icon icon-class="password" />
            </el-button>
            <el-button slot="append" @click="showPwd">
              <svg-icon :icon-class="pwdType === 'password' ? 'eye' : 'eye-open'" />
            </el-button>
          </el-input>
        </el-form-item>
        <el-form-item style="backgound:transparent;border:0px;">
          <el-button
            :loading="loading"
            type="primary"
            style="width:48%;"
            @click.native.prevent="handleLogin"
          >
            Login
          </el-button>
          <el-button
            :loading="loading"
            type="warning"
            style="width:48%;"
            @click.native.prevent="handleRegister"
          >
            Register
          </el-button>
        </el-form-item>
        <div class="tips" />
      </el-form>
    </div>
    <el-dialog :visible.sync="registerDialogVisible" title="Student Register" width="35%">
      <div class="dialog-content">
        <el-form ref="registerForm" :model="registerForm" :rules="registerRules" label-position="left" label-width="150px">
          <el-row>
            <el-col :span="16">
              <el-form-item :error="errors.registerusername_error" label="Login Name" prop="name">
                <el-input v-model="registerForm.name" :rows="1" placeholder="Login Name"/>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="16">
              <el-form-item label="Email" prop="email">
                <el-input :rows="1" v-model="registerForm.email" placeholder="Email"/>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="16">
              <el-form-item label="Password" prop="password" status-icon inline-message>
                <el-input v-model="registerForm.password" type="password" placeholder="Password" autocomplete="off" show-password/>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="16">
              <el-form-item label="Confirm Password" prop="checkpwd" status-icon inline-message>
                <el-input v-model="registerForm.checkpwd" type="password" placeholder="Check Password" autocomplete="off" show-password/>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="16">
              <el-form-item label="Gender" prop="gender">
                <el-select v-model="registerForm.gender">
                  <el-option label="Male" value="male"/>
                  <el-option label="Female" value="female"/>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="16">
              <el-form-item label="Age" prop="age">
                <el-input-number v-model="registerForm.age" :min="12" :max="35" controls-position="right"/>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="16">
              <el-form-item label="Favorite Color" prop="color">
                <el-color-picker v-model="registerForm.color" size="medium"/>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>

      </div>
      <div slot="footer" class="dialog-footer">
        <el-button @click="handleOpertionCancel">Cancel</el-button>
        <el-button :loading="dialogTableLoading" type="primary" @click="doRegister()">Done</el-button>
      </div>
    </el-dialog>
  </div>

</template>

<script>
import { isvalidUsername, validateEmail, validatePassword } from '@/utils/validate'
import minLogo from '@/assets/logo-min.jpg'
import { stuRegister } from '@/api/user'
import { deepClone } from '@/utils/index'
export default {
  name: 'Login',
  data() {
    const validateEmail_register = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('Please Enter your Email'))
      } else {
        if (!validateEmail(value)) {
          callback(new Error('Wrong Email Format'))
        } else {
          callback()
        }
      }
    }
    const validateUsername = (rule, value, callback) => {
      if (!isvalidUsername(value)) {
        callback(new Error('Enter your username'))
      } else {
        callback()
      }
    }
    const validatePass = (rule, value, callback) => {
      if (value.length === 0) {
        callback(new Error('Enter your password'))
      } else {
        callback()
      }
    }
    var validatePass_register = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('Please enter password'))
      } else if (!validatePassword(value)) {
        callback(new Error('6-20 digits, upper and lower case characters'))
      } else {
        if (this.registerForm.checkpwd !== '') {
          this.$refs.registerForm.validateField('checkpwd')
        }
        callback()
      }
    }
    var validatePass2_register = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('Please enter password again'))
      } else if (value !== this.registerForm.password) {
        callback(new Error('The two passwords do not match!'))
      } else {
        callback()
      }
    }
    return {
      minLogo,
      loginForm: {
        username: '',
        password: '',
        domain: 'stu'
      },
      registerForm: {
        name: '',
        password: '',
        checkpwd: '',
        gender: '',
        email: '',
        age: 12,
        color: ''
      },
      errors: {
        username_error: '',
        password_error: '',
        registerusername_error: ''
      },
      loginRules: {
        username: [{ required: true, trigger: 'blur', validator: validateUsername }],
        password: [{ required: true, trigger: 'blur', validator: validatePass }]
      },
      registerRules: {
        name: [
          { required: true, message: 'Pleace enter your login name', trigger: 'blur' }
        ],
        gender: [
          { required: true, message: 'Pleace choose your gender', trigger: 'change' }
        ],
        email: [
          { required: true, validator: validateEmail_register, trigger: 'blur' }
        ],
        color: [
          { required: true, message: 'Pleace select a color for your scheduler', trigger: 'blur' }
        ],
        age: [
          { required: true, message: 'Pleace enter your age', trigger: 'change' }
        ],
        password: [
          { required: true, validator: validatePass_register, trigger: 'blur' }
        ],
        checkpwd: [
          { required: true, validator: validatePass2_register, trigger: 'blur' }
        ]
      },
      loading: false,
      pwdType: 'password',
      redirect: undefined,
      registerDialogVisible: false,
      dialogTableLoading: false
    }
  },
  watch: {
    $route: {
      handler: function(route) {
        this.redirect = route.query && route.query.redirect
      },
      immediate: true
    }
  },
  methods: {
    doRegister: function() {
      this.$refs.registerForm.validate(valid => {
        if (valid) {
          this.$confirm('Confirm to Register?', 'Warning', {
            confirmButtonText: 'Confirm',
            cancelButtonText: 'Cancel',
            type: 'warning'
          }).then(() => {
            this.dialogTableLoading = true
            const registerinfo = deepClone(this.registerForm)
            stuRegister(registerinfo).then(response => {
              if (response.error_code === 0) {
                this.$message({
                  type: 'success',
                  message: response.msg
                })
                this.handleOpertionCancel()
              } else {
                this.$message({
                  type: 'error',
                  message: response.msg
                })
                this.errors.registerusername_error = response.msg
              }
            }).catch(err => {
              console.log(err)
            })
          }).catch(() => {
            this.$message({
              type: 'info',
              message: 'Cancel to register'
            })
          })
        }
      })
    },
    handleOpertionCancel: function() {
      this.registerDialogVisible = false
      this.dialogTableLoading = false
      this.$refs.registerForm.resetFields()
    },
    handleRegister() {
      this.registerDialogVisible = true
    },
    showPwd() {
      if (this.pwdType === 'password') {
        this.pwdType = ''
      } else {
        this.pwdType = 'password'
      }
    },
    handleLogin() {
      this.$refs.loginForm.validate(valid => {
        if (valid) {
          this.loading = true
          console.log(this.loginForm)
          this.$store.dispatch('Login', this.loginForm).then(() => {
            this.loading = false
            this.$notify({
              title: 'Login Success',
              message: 'Please wait for loading data',
              type: 'success',
              duration: 1000
            })
            this.$router.push({ path: '/' })
          }).catch(() => {
            setTimeout(() => {
              this.loading = false
            }, 500)
          })
          this.loading = false
        } else {
          return false
        }
      })
    },
    handleWithoutLogin() {
      this.$router.push('/')
    }
  }
}
</script>
<style rel="stylesheet/scss" lang="scss">
/* 修复input 背景不协调 和光标变色 */
/* Detail see https://github.com/PanJiaChen/vue-element-admin/pull/927 */

$bg: #283443;
$light_gray: #eee;
$cursor: #fff;

@supports (-webkit-mask: none) and (not (cater-color: $cursor)) {
  .login-container .el-input input {
    color: $cursor;
    &::first-line {
      color: $light_gray;
    }
  }
}

/* reset element-ui css */
.login-container {
  .el-select .el-input {
  width: 130px;
}
  .el-input {
    input {
      background: transparent;
      border: 0px;
      -webkit-appearance: none;
      border-radius: 0px;
      padding: 12px 5px 12px 15px;
      color: $light_gray;
      height: 47px;
      caret-color: $cursor;
      &:-webkit-autofill {
        -webkit-box-shadow: 0 0 0px 1000px $bg inset !important;
        -webkit-text-fill-color: $cursor !important;
      }
    }
    .el-input-group__prepend {
      background: transparent;
      border: 0px;
    }
    .el-input-group__append{
      background: transparent;
      border: 0px;
    }
  }
  .el-form-item {
    border: 1px solid rgba(255, 255, 255, 0.1);
    background: rgba(0, 0, 0, 0.1);
    border-radius: 5px;
    color: #454545;
  }
}
</style>
<style rel="stylesheet/scss" lang="scss" scoped>
$bg: #2d3a4b;
$dark_gray: #889aa4;
$light_gray: #eee;

.login-wrapper{
  min-height: 100%;
  width: 100%;
  background-color: $bg;
  overflow: hidden;
.login-container {
  .login-form {
    position: relative;
    width: 520px;
    max-width: 100%;
    padding: 160px 35px 0;
    margin: 0 auto;
    overflow: hidden;
  }
  .tips {
    font-size: 14px;
    color: #fff;
    margin-bottom: 10px;
    span {
      &:first-of-type {
        margin-right: 16px;
      }
    }
  }
  .svg-container {
    padding: 6px 5px 6px 15px;
    color: $dark_gray;
    vertical-align: middle;
    width: 30px;
    display: inline-block;
  }
  .title-container {
    position: relative;
    display: flex;
    align-items: center;
    flex-direction: row;
    justify-content: space-evenly;
    margin-bottom: 20px;
    .logo-con {
      padding: 10px 2px;
      img {
        height: 44px;
        width: auto;
        margin: 0 auto;
      }
    }
    .title {
      font-size: 20px;
      color: $light_gray;
      text-align: center;
      font-weight: bold;
    }
  }
  .show-pwd {
    position: absolute;
    right: 10px;
    top: 7px;
    font-size: 16px;
    color: $dark_gray;
    cursor: pointer;
    user-select: none;
  }
  .thirdparty-button {
    position: absolute;
    right: 0;
    bottom: 6px;
  }
}
}
.dialog-content {
  padding-left: 20px;
}
</style>
