<template>
  <el-card
    :class="{ box_card_hiddenbody :!isPanelOpen,}"
    class="box-card"
    shadow="never"
  >
    <div slot="header">
      <div class="head-title">
        <div class="head-text">
          <slot name="header-title"/>
        </div>

        <div
          v-show="foldable"
          :class="{'rotate':isPanelOpen,'prerotate':!isPanelOpen}"
          class="action-wrapper"
        >
          <i
            class="el-icon-remove-outline"
            @click="controlPanel"
          />
        </div>

      </div>

    </div>
    <div :class="{'close':!isPanelOpen}" class="card_body-container">
      <div v-show="isPanelOpen">
        <slot />
      </div>
      <div v-show="!isPanelOpen">
        <slot name="body_mini"/>
      </div>
    </div>
  </el-card>
</template>
<script>
export default {
  props: {
    foldable: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      isPanelOpen: true,
      show: false
    }
  },
  watch: {
    show(value) {
      if (value) {
        document.body.addEventListener('click', this.close)
      } else {
        document.body.removeEventListener('click', this.close)
      }
    }
  },
  methods: {
    click() {
      this.show = !this.show
      if (this.show) {
        this.$refs.head_search_input && this.$refs.head_search_input.focus()
      }
    },
    close() {
      this.$refs.head_search_input && this.$refs.head_search_input.blur()
      setTimeout(() => {
        this.input2 = ''
        this.show = false
      }, 200)
    },
    controlPanel: function() {
      this.isPanelOpen = !this.isPanelOpen
    }
  }
}
</script>

<style lang="scss" scoped>
.box-card /deep/ .el-card__header {
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.4);
  background: #6699CC;
  color:#fff;
  border: 0px;
  border-radius: 5px;
  padding: 10px;
  height: 50px;
}
.box-card /deep/ .el-card__body {
  padding: 0;
  margin: -25px 10px 0px 10px;
  background-color: transparent;
}
.box-card {
  border: 0px;
  padding-top: 15px;
  padding-bottom: 15px;
  background-color: transparent;
  overflow: visible;
  .head-title {
    margin-top: -5px;
    .head-text {
      display: inline-block;
      vertical-align: middle;
      padding-left: 10px;
      margin:10px;
    }
    .action-wrapper {
      float: right;
      margin: 10px;
      font-size: 20px;
      transform: rotate(0deg);
      transition: all 0.2s;
      &.rotate {
        transform: rotate(90deg);
        transition: all 0.2s;
      }
    }
  }

  .card_body-container {
    margin-top: 35px;
    transition: min-height .5s;
    border: 1px solid #ebeef5;
    border-radius: 5px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.4);
    background-color: #fff;
    padding: 15px;
    min-height: 200px;
    &.close{
        min-height: 70px;
    }
  }
}
.box_card_hiddenbody {
  padding-top: 18px;
  padding-bottom: 18px;
}

.text {
  font-size: 14px;
}

.item {
  margin-bottom: 18px;
}
</style>
