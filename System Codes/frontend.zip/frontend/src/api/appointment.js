import request from '@/utils/request'

export function updateAppointment(form) {
  return request({
    url: '/v1/appointment/update',
    method: 'post',
    data: JSON.stringify(form)
  })
}

export function updateTestPoints(data) {
  return request({
    url: '/v1/appointment/calculate',
    method: 'post',
    data
  })
}
export function getAppointmentInfo(appointment_id) {
  return request({
    url: '/v1/appointment/' + appointment_id,
    method: 'get'
  })
}

export function getAppointmentByCid(course_id) {
  return request({
    url: '/v1/appointment/searchbycid',
    method: 'post',
    data: {
      course_id
    }
  })
}

export function getAppointmentBySidCid(stu_id, course_id) {
  return request({
    url: '/v1/appointment/searchbysidcid',
    method: 'post',
    data: {
      stu_id,
      course_id
    }
  })
}

export function getAppointmentInfoList(form) {
  return request({
    url: '/v1/appointment/list',
    method: 'post',
    data: JSON.stringify(form)
  })
}

export function updateAppointmentStatus(app_id, status) {
  return request({
    url: '/v1/appointment/updatestatus',
    method: 'post',
    data: {
      app_id,
      status
    }
  })
}
