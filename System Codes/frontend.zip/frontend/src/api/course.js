import request from '@/utils/request'

export function updateCourseInfo(form) {
  return request({
    url: '/v1/course/update',
    method: 'post',
    data: JSON.stringify(form)
  })
}

export function getCourseList(course_id) {
  if (course_id && course_id !== 0) {
    return request({
      url: '/v1/course/list',
      method: 'post',
      data: {
        id: course_id
      }
    })
  } else {
    return request({
      url: '/v1/course/list',
      method: 'post'
    })
  }
}

export function askforsch(course_id) {
  return request({
    url: '/v1/course/askforsch?id=' + course_id,
    method: 'get'
  })
}

export function doScheduleForCourse(course_id) {
  return request({
    url: '/v1/course/doschedule',
    method: 'post',
    data: {
      id: course_id
    }
  })
}

export function updateLifeCycle(data) {
  return request({
    url: '/v1/course/updatelifecycle',
    method: 'post',
    data
  })
}

export function getTotalClassNum(data) {
  return request({
    url: '/v1/course/getTotalClassNum',
    method: 'post',
    data
  })
}
