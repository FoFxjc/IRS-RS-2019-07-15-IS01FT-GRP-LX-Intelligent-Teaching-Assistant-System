import request from '@/utils/request'

export function getCalendar() {
  return request({
    url: 'v1/calendar/list',
    method: 'post' // method post in the pro
  })
}
export function getCalendarByCourse_id(course_id) {
  return request({
    url: 'v1/calendar/getCalendarByCid',
    method: 'post',
    data: {
      course_id
    }
  })
}