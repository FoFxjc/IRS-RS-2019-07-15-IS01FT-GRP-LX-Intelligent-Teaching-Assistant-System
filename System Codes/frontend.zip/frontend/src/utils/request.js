import axios from 'axios'
import { Message, MessageBox } from 'element-ui'
import store from '../store'
import {
  getToken
} from '@/utils/auth'

// 创建axios实例

const base_url = IPCONFIG

const service = axios.create({
  baseURL: base_url, // api 的 base_url
  timeout: 8000 // 请求超时时间
})

// request拦截器
service.interceptors.request.use(
  config => {
    if (store.getters.token) {
      config.auth = {
        username: getToken()
      }
    }
    config.headers = {
      'Content-Type': 'application/json'
    }
    return config
  },
  error => {
    Promise.reject(error)
  }
)

// response 拦截器
service.interceptors.response.use(
  response => {
    const res = response.data
    if (res.code === 401) {
      MessageBox.confirm(
        'Your token has expired. Please re-login or stay on the current page.',
        'Confirm Re-login', {
          confirmButtonText: 'Relogin',
          cancelButtonText: 'cancel',
          type: 'warning'
        }
      ).then(() => {
        store.dispatch('LogOut').then(() => {
          location.reload() // 为了重新实例化vue-router对象 避免bug
        })
      })
      return Promise.reject('error')
    } else {
      return response.data
    }
  },
  error => {
    if (error.response.status === 404) {
      return error.response
    } else if (error.response.status === 403) {
      Message({
        message: 'You have no auth to do that action',
        type: 'error',
        duration: 5 * 1000
      })
      return Promise.reject(error)
    } else {
      Message({
        message: error.message,
        type: 'error',
        duration: 3 * 1000
      })
      return Promise.reject(error)
    }
  }
)

export default service
