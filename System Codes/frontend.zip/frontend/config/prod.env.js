'use strict'

module.exports = {
  NODE_ENV: '"production"',
  BASE_API: '"http://172.19.0.10:5000"'
}
