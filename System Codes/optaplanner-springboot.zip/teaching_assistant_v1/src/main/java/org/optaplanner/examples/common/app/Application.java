package org.optaplanner.examples.common.app;

import org.apache.commons.io.output.ByteArrayOutputStream;
import org.optaplanner.core.api.score.Score;
import org.optaplanner.examples.common.business.SolutionBusiness;
import org.optaplanner.examples.teachingassistant.domain.TeachingSolution;
import org.optaplanner.persistence.common.api.domain.solution.SolutionFileIO;
import org.optaplanner.persistence.xstream.impl.domain.solution.XStreamSolutionFileIO;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;


@RestController
@SpringBootApplication
@Configuration
public class Application {

    public static final String DATA_DIR_SYSTEM_PROPERTY = "org.optaplanner.examples.dataDir";
    public static final String DATA_DIR_NAME = "teachingassistant";
    public static final String SOLVER_CONFIG
            = "org/optaplanner/examples/teachingassistant/solver/teachingSolverConfig.xml";

    public static SolutionBusiness<TeachingSolution> solutionBusiness;
    static TeachingSolution T, P;
    static SolveMe<TeachingSolution> s = new SolveMe<TeachingSolution>();


    public static SolutionBusiness<TeachingSolution> createSolutionBusiness() {
        SolutionBusiness<TeachingSolution> solutionBusiness = new SolutionBusiness<>();
        solutionBusiness.setSolver(s.createSolver(new ClassPathResource(SOLVER_CONFIG).getPath()));
        solutionBusiness.setSolutionFileIO(new XStreamSolutionFileIO<>(TeachingSolution.class));
        return solutionBusiness;
    }


    public SolutionFileIO<TeachingSolution> createSolutionFileIO() {
        return new XStreamSolutionFileIO<>(TeachingSolution.class);
    }


    public synchronized static void doit(TeachingSolution P) {

        T = (solutionBusiness.solve(P));

    }


    @RequestMapping(value = "/solve")
    public TeachingSolution spring_solve(HttpServletRequest request) {
        String xml_data = new String("not therer");
        try {
            xml_data = new String(readInputStream(request.getInputStream()), "UTF-8");
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (xml_data.length() != 0) {
            Date date = new Date();
            String filepath = "data/teachingassistant/unsolved/";
            String filename = "unsolved_" + date.getTime() + ".xml";
            File file = new File(filepath + filename);
            FileWriter fw = null;
            try {
                if (!file.exists()) {
                    file.createNewFile();
                }
                fw = new FileWriter(file);
                fw.write(xml_data);
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (null != fw) {
                    try {
                        fw.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            solutionBusiness = createSolutionBusiness();
            solutionBusiness.openSolution(file);
            P = solutionBusiness.getSolution();
            doit(P);
            Score score1 = solutionBusiness.getScore();

            return T;
        }
        return null;
    }
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    public static byte[] readInputStream(InputStream inStream) throws Exception {
        ByteArrayOutputStream outSteam = new ByteArrayOutputStream();
        byte[] buffer = new byte[1024];
        boolean var3 = false;

        int len;
        while((len = inStream.read(buffer)) != -1) {
            outSteam.write(buffer, 0, len);
        }

        outSteam.close();
        inStream.close();
        return outSteam.toByteArray();
    }
}
