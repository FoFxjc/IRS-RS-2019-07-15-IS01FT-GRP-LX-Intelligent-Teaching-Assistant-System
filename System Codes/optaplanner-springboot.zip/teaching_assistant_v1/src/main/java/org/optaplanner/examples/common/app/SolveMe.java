package org.optaplanner.examples.common.app;

import org.optaplanner.core.api.solver.Solver;
import org.optaplanner.core.api.solver.SolverFactory;

public class SolveMe<Solution_> {
	
	protected Solver<Solution_> createSolver(String solverConfig) {
        SolverFactory<Solution_> solverFactory = SolverFactory.createFromXmlResource(solverConfig, getClass().getClassLoader());
        if(solverFactory==null)
        	System.out.print("null solver");  
        return solverFactory.buildSolver();
    }

}
