///*
// * Copyright 2013 Red Hat, Inc. and/or its affiliates.
// *
// * Licensed under the Apache License, Version 2.0 (the "License");
// * you may not use this file except in compliance with the License.
// * You may obtain a copy of the License at
// *
// *      http://www.apache.org/licenses/LICENSE-2.0
// *
// * Unless required by applicable law or agreed to in writing, software
// * distributed under the License is distributed on an "AS IS" BASIS,
// * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// * See the License for the specific language governing permissions and
// * limitations under the License.
// */
//
//package org.optaplanner.examples.teachingassistant.persistence;
//
//import java.io.File;
//import java.math.BigInteger;
//import java.util.ArrayList;
//import java.util.List;
//
//import org.optaplanner.examples.common.app.CommonApp;
//import org.optaplanner.examples.common.app.LoggingMain;
//import org.optaplanner.examples.common.persistence.AbstractSolutionImporter;
//import org.optaplanner.examples.teachingassistant.app.TeachingAssistantApp;
//import org.optaplanner.examples.teachingassistant.domain.Period;
//import org.optaplanner.examples.teachingassistant.domain.Student;
//import org.optaplanner.examples.teachingassistant.domain.StudentAssignment;
//import org.optaplanner.examples.teachingassistant.domain.TeachingSolution;
//import org.optaplanner.examples.teachingassistant.domain.UnavailabilityPenalty;
//import org.optaplanner.persistence.common.api.domain.solution.SolutionFileIO;
//import org.optaplanner.persistence.xstream.impl.domain.solution.XStreamSolutionFileIO;
//
//public class TeachingGenerator extends LoggingMain {
//
//    public static void main(String[] args) {
//        new TeachingGenerator().generate();
//    }
//
//    protected final SolutionFileIO<TeachingSolution> solutionFileIO;
//    protected final File outputDir;
//
//    public TeachingGenerator() {
//        solutionFileIO = new XStreamSolutionFileIO<>(TeachingSolution.class);
//        outputDir = new File(CommonApp.determineDataDir(TeachingAssistantApp.DATA_DIR_NAME), "unsolved");
//    }
//
//    public void generate() {
//        File outputFile = new File(outputDir, "munich-7teams.xml");
//        TeachingSolution teachingSolution = createTeachingSolution();
//        solutionFileIO.write(teachingSolution, outputFile);
//        logger.info("Saved: {}", outputFile);
//    }
//
//    public TeachingSolution createTeachingSolution() {
//        TeachingSolution teachingSolution = new TeachingSolution();
//        teachingSolution.setId(0L);
//
//        List<Student> studentList = new ArrayList<>();
//        studentList.add(new Student(0L, "Student1"));
//        studentList.add(new Student(1L, "Student2"));
//        studentList.add(new Student(2L, "Student3"));
//        studentList.add(new Student(3L, "Student4"));
//        studentList.add(new Student(4L, "Student5"));
//        studentList.add(new Student(5L, "Student6"));
//        studentList.add(new Student(6L, "Student7"));
//        teachingSolution.setStudentList(studentList);
//
//        List<Period> periodList = new ArrayList<>();
//        for (int i = 0; i < 18; i++) {
//            periodList.add(new Period(i, i));
//        }
//        teachingSolution.setPeriodList(periodList);
//
//        List<UnavailabilityPenalty> unavailabilityPenaltyList = new ArrayList<>();
//        unavailabilityPenaltyList.add(new UnavailabilityPenalty(0L, studentList.get(4), periodList.get(0)));
//        unavailabilityPenaltyList.add(new UnavailabilityPenalty(1L, studentList.get(6), periodList.get(1)));
//        unavailabilityPenaltyList.add(new UnavailabilityPenalty(2L, studentList.get(2), periodList.get(2)));
//        unavailabilityPenaltyList.add(new UnavailabilityPenalty(3L, studentList.get(4), periodList.get(3)));
//        unavailabilityPenaltyList.add(new UnavailabilityPenalty(4L, studentList.get(4), periodList.get(5)));
//        unavailabilityPenaltyList.add(new UnavailabilityPenalty(5L, studentList.get(2), periodList.get(6)));
//        unavailabilityPenaltyList.add(new UnavailabilityPenalty(6L, studentList.get(1), periodList.get(8)));
//        unavailabilityPenaltyList.add(new UnavailabilityPenalty(7L, studentList.get(2), periodList.get(9)));
//        unavailabilityPenaltyList.add(new UnavailabilityPenalty(8L, studentList.get(4), periodList.get(10)));
//        unavailabilityPenaltyList.add(new UnavailabilityPenalty(9L, studentList.get(4), periodList.get(11)));
//        unavailabilityPenaltyList.add(new UnavailabilityPenalty(10L, studentList.get(6), periodList.get(12)));
//        unavailabilityPenaltyList.add(new UnavailabilityPenalty(11L, studentList.get(5), periodList.get(15)));
//        teachingSolution.setUnavailabilityPenaltyList(unavailabilityPenaltyList);
//
//        List<StudentAssignment> studentAssignmentList = new ArrayList<>();
//        long id = 0L;
//        for (Period period : periodList) {
//            for (int i = 0; i < 4; i++) {
//                studentAssignmentList.add(new StudentAssignment(id, period, i));
//                id++;
//            }
//        }
//        teachingSolution.setStudentAssignmentList(studentAssignmentList);
//
//        BigInteger possibleSolutionSize = BigInteger.valueOf(studentList.size()).pow(
//                studentAssignmentList.size());
//        logger.info("The teacher {} has {} students, {} periods, {} unavailabilityPenalties and {} studentAssignments"
//                + " with a search space of {}.",
//                "test-7students", studentList.size(), periodList.size(), unavailabilityPenaltyList.size(), studentAssignmentList.size(),
//                AbstractSolutionImporter.getFlooredPossibleSolutionSize(possibleSolutionSize));
//        return teachingSolution;
//    }
//
//}
